Skills That Fire, Work & Learn — Agent Skills talk (Shahyar Taheri, Sept 2026)

index.html   The whole deck in one file. Open it in Chrome or Edge, press F for full screen.
             Keys: → / Space next, ← back, N speaker notes + pace clock, O slide list, ? shortcuts.
             Fonts load from Google Fonts; offline it falls back to system fonts.
src/         Sources. Edit the slides, CSS or JS, then rebuild with:
               cd src && python3 build.py      (writes ../index.html)
