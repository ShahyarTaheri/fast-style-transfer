/* ==========================================================================
   Demo: description lab — tune a description on "learn" requests, judge it
   on hidden ones. Simulated replay with illustrative results (3 tries each).
   ========================================================================== */
(() => {
  'use strict';
  const H = window.DeckH;
  const $ = (s, r) => r.querySelector(s);
  const $$ = (s, r) => Array.from(r.querySelectorAll(s));
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const V = [
    'Generate reports.',
    'Create portfolio performance reports with returns and charts. Use when the user asks for a client report.',
    'Build client portfolio performance reviews: time-weighted returns, benchmark comparison and attribution by asset class. Use when someone asks how an account or household performed, needs a quarterly review, or mentions returns or benchmarks, even without saying "report".',
  ];
  V[3] = V[2] + ' Not for real-time P&L, trading, rebalancing, report templates, or writing SQL and data pipelines.';
  V[4] = V[3] + ' Also use for the Hartleys, Q3 packs, 60/40 comparisons, trusts, IRAs and underperformance.';

  const WHY = [
    'The starting point.',
    'Misses questions that never say “report”, and fires on report-ish code tasks. → say what it does and when to use it.',
    'Still misses “how did…” and “why did… lag” questions. → name what people actually ask, “even without saying report”.',
    'Now fires on near-misses: rebalancing, P&amp;L scripts, report templates. → add a <b>NOT</b> sentence.',
    'One learn request still missed. → paste in names and phrases from failed requests. <b class="u-fail">That\'s overfitting.</b>',
  ];

  // [should fire?, set, request, times fired out of 3 for v0..v4]
  const Q = [
    ['yes', 'learn', 'Hartley household: how did the balanced portfolio do vs the 60/40 benchmark last quarter?', [0, 1, 3, 3, 3]],
    ['yes', 'learn', 'my advisor needs the Q3 review pack for client 88213 by friday', [0, 1, 3, 3, 3]],
    ['yes', 'learn', 'Generate the quarterly report for account 4471 with returns by asset class', [2, 3, 3, 3, 3]],
    ['yes', 'learn', 'Create a YTD performance report for the Johnson trust with a benchmark chart', [3, 3, 3, 3, 3]],
    ['yes', 'learn', 'why did the Chen IRA underperform in September?', [0, 0, 2, 1, 3]],
    ['yes', 'learn', 'report on IRR vs TWR for the Patel family accounts since inception', [2, 2, 3, 3, 3]],
    ['no', 'learn', 'Rebalance the Smith IRA back to its target weights', [0, 0, 2, 0, 0]],
    ['no', 'learn', 'write a python script that pulls daily P&L from the risk API into our dashboard', [2, 2, 2, 1, 0]],
    ['no', 'learn', 'Design a database schema for client households and accounts', [0, 0, 0, 0, 0]],
    ['no', 'learn', 'Fix the failing unit test in calc_twr()', [2, 1, 1, 0, 0]],
    ['no', 'learn', 'Generate a report template for the quarterly compliance attestation', [3, 1, 2, 0, 0]],
    ['no', 'learn', 'set up a cron job that archives yesterday\'s trade files', [0, 0, 1, 1, 0]],
    ['yes', 'hidden', 'how did my accounts do this year compared to the S&P 500?', [3, 3, 3, 3, 3]],
    ['yes', 'hidden', 'what\'s the money-weighted return on account 7788 since onboarding?', [1, 2, 3, 3, 3]],
    ['yes', 'hidden', 'The Garcias are asking why their growth sleeve lagged. Can you pull numbers for the meeting?', [0, 0, 2, 3, 1]],
    ['yes', 'hidden', 'quick check before the client review: returns look off for account 2201, anything weird?', [2, 2, 3, 3, 3]],
    ['no', 'hidden', 'what\'s the quickest way to convert this JSON trade file to CSV?', [0, 0, 0, 0, 0]],
    ['no', 'hidden', 'Write a SQL view that reports daily cash balances for the ops team', [2, 2, 2, 0, 2]],
    ['no', 'hidden', 'Summarize this 10-K for me', [0, 0, 0, 0, 0]],
    ['no', 'hidden', 'Explain the difference between TWR and IRR', [0, 0, 1, 0, 1]],
  ];
  const pass = (q, v) => (q[0] === 'yes' ? q[3][v] >= 2 : q[3][v] <= 1);
  const rate = (set, v) => {
    const qs = Q.filter((q) => q[1] === set);
    return qs.filter((q) => pass(q, v)).length / qs.length;
  };

  // step → which version is shown / evaluated
  const VER = [0, 0, 1, 2, 3, 4, 3, 3];
  const EVALS = [-1, 0, 1, 2, 3, 4, 4, 4];

  Deck.demo('lab', {
    init(sl) {
      const box = $('.lab', sl);
      const row = (q, i) => `<div class="lb-q ${q[0]}" data-i="${i}"><span class="lb-runs" aria-label="fired in 3 tries"><i></i><i></i><i></i></span><span class="lb-t" title="${esc(q[2])}">${esc(q[2])}</span><span class="lb-exp mono">${q[0]}</span><span class="lb-res"></span></div>`;
      const head = '<div class="lb-q lb-hd"><span class="mono">3 tries</span><span class="mono">request</span><span class="mono">fire?</span><span class="mono">result</span></div>';
      box.innerHTML =
        '<div class="lb-top">' +
        '<div class="lb-desc"><div class="row between center-y"><span class="label">description · <b class="lb-ver mono">v0</b></span><span class="lb-len mono"></span></div>' +
        '<p class="lb-dtext mono"></p><div class="lb-why small"></div></div>' +
        '<div class="lb-chart"><svg viewBox="0 0 560 226" class="lb-svg" aria-label="Score on learn and hidden requests per version"></svg></div>' +
        '</div>' +
        '<div class="lb-cols">' +
        '<div class="lb-col"><div class="lb-h"><span class="mono">learn · 12</span><span class="label">we edit using these</span><span class="lb-score mono" data-s="learn"></span></div>' + head +
        Q.map((q, i) => (q[1] === 'learn' ? row(q, i) : '')).join('') + '</div>' +
        '<div class="lb-col hidden-set"><div class="lb-h"><span class="mono">hidden · 8 🔒</span><span class="label">never shown to the editor</span><span class="lb-score mono" data-s="hidden"></span></div>' + head +
        Q.map((q, i) => (q[1] === 'hidden' ? row(q, i) : '')).join('') +
        '<div class="lb-ctrl"><span class="lb-legend"><i class="lg-on"></i> fired <i class="lg-off"></i> didn\'t fire</span><button type="button" class="btn lb-auto">▶ Auto-play</button><button type="button" class="btn ghost lb-reset">Reset</button></div>' +
        '</div></div>';
      this.chart(sl);
      $('.lb-auto', box).addEventListener('click', (e) => { e.currentTarget.blur(); this.autoplay(sl); });
      $('.lb-reset', box).addEventListener('click', (e) => { e.currentTarget.blur(); clearInterval(sl._auto); Deck.go(Deck.cur, 0, { instant: true }); });
    },
    autoplay(sl) {
      clearInterval(sl._auto);
      if (Deck.step >= 7) Deck.go(Deck.cur, 0, { instant: true });
      sl._auto = setInterval(() => {
        if (Deck.slides[Deck.cur] !== sl || Deck.step >= 7) { clearInterval(sl._auto); return; }
        Deck.next();
      }, 3600);
      Deck.next();
    },
    chart(sl) {
      const svg = $('.lb-svg', sl);
      const L = 46, T = 32, W = 490, Hh = 134;
      const x = (v) => L + (v / 4) * W, y = (r) => T + (1 - r) * Hh;
      sl._cx = x; sl._cy = y;
      [0, 0.5, 1].forEach((r) => {
        H.S('line', { x1: L, y1: y(r), x2: L + W, y2: y(r), cls: 'sv-grid' }, svg);
        H.S('text', { x: L - 10, y: y(r) + 5, 'text-anchor': 'end', cls: 'sv-tick mono', text: r * 100 + '%' }, svg);
      });
      for (let v = 0; v <= 4; v++) H.S('text', { x: x(v), y: T + Hh + 26, 'text-anchor': 'middle', cls: 'sv-tick mono', text: 'v' + v }, svg);
      sl._best = H.S('rect', { x: x(3) - 26, y: T - 6, width: 52, height: Hh + 12, rx: 8, cls: 'lb-best' }, svg);
      sl._bestT = H.S('text', { x: x(3), y: T + Hh + 50, 'text-anchor': 'middle', cls: 'lb-best-t mono', text: 'best on hidden' }, svg);
      sl._pTrain = H.S('path', { cls: 'lb-line learn' }, svg);
      sl._pVal = H.S('path', { cls: 'lb-line hidden' }, svg);
      sl._dots = [];
      for (let v = 0; v <= 4; v++) {
        sl._dots.push([
          H.S('circle', { cx: x(v), cy: y(rate('learn', v)), r: 6, cls: 'lb-dot learn' }, svg),
          H.S('circle', { cx: x(v), cy: y(rate('hidden', v)), r: 6, cls: 'lb-dot hidden' }, svg),
        ]);
      }
      H.S('text', { x: L, y: 14, cls: 'lb-leg learn mono', text: '— learn' }, svg);
      H.S('text', { x: L + 84, y: 14, cls: 'lb-leg hidden mono', text: '- - hidden' }, svg);
    },
    drawChart(sl, upto) {
      const pts = (set) => Array.from({ length: upto + 1 }, (_, v) => (v ? 'L' : 'M') + sl._cx(v) + ',' + sl._cy(rate(set, v))).join(' ');
      sl._pTrain.setAttribute('d', upto >= 0 ? pts('learn') : '');
      sl._pVal.setAttribute('d', upto >= 0 ? pts('hidden') : '');
      sl._dots.forEach(([a, b], v) => { a.classList.toggle('on', v <= upto); b.classList.toggle('on', v <= upto); });
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      if (instant) clearInterval(sl._auto);
      const box = $('.lab', sl);
      const ver = VER[s], ev = EVALS[s];
      const prevVer = sl._ver;
      sl._ver = ver;
      const txt = V[ver];
      const dEl = $('.lb-dtext', box);
      const prevTxt = prevVer !== undefined ? V[prevVer] : '';
      if (!instant && prevVer !== undefined && prevVer !== ver && prevTxt && txt.startsWith(prevTxt)) {
        dEl.innerHTML = 'description: ' + esc(prevTxt) + '<ins>' + esc(txt.slice(prevTxt.length)) + '</ins>';
      } else if (!instant && prevVer !== undefined && prevVer !== ver) {
        dEl.innerHTML = 'description: <ins class="all">' + esc(txt) + '</ins>';
      } else dEl.innerHTML = 'description: ' + esc(txt);
      $('.lb-ver', box).textContent = 'v' + ver + (s >= 6 ? ' · chosen' : '');
      $('.lb-ver', box).classList.toggle('sel', s >= 6);
      $('.lb-len', box).innerHTML = `${txt.length} / 1,024 chars`;
      $('.lb-why', box).innerHTML = s === 0 ? '20 requests · 12 to learn from, 8 hidden · each tried 3 times · a row passes if the skill fired (or stayed quiet) at least 2 of 3 times'
        : s <= 5 ? '<span class="mono u-accent">edit</span> ' + WHY[ver]
        : s === 6 ? '<span class="mono u-accent">choose</span> Pick the version with the best <b>hidden</b> score: <b>v3</b> (100%), not the last one (v4 scores 75% on hidden).'
        : '<span class="mono u-accent">ship</span> Put v3 in SKILL.md, then try 5–10 <b>brand-new</b> requests as a last check.';
      const resultV = s >= 6 ? 3 : (ev >= 0 ? Math.min(ev, 4) : -1);
      const evalAnim = !instant && s >= 1 && s <= 5 && sl._lastEval !== resultV;
      $$('.lb-q:not(.lb-hd)', box).forEach((row) => {
        const q = Q[+row.dataset.i];
        const runs = $$('.lb-runs i', row);
        const res = $('.lb-res', row);
        row.classList.remove('pass', 'fail', 'hot');
        if (resultV < 0) { runs.forEach((d) => d.classList.remove('on', 'hit')); res.innerHTML = ''; return; }
        const t = q[3][resultV], ok = pass(q, resultV);
        const paint = () => {
          runs.forEach((d, k) => { d.classList.add('on'); d.classList.toggle('hit', k < t); });
          res.innerHTML = `<span class="${ok ? 'pill-pass' : 'pill-fail'}">${ok ? 'PASS' : 'FAIL'}</span>`;
          row.classList.add(ok ? 'pass' : 'fail');
          if (!ok && q[1] === 'learn' && s <= 5) row.classList.add('hot');
        };
        if (evalAnim) {
          runs.forEach((d) => d.classList.remove('on', 'hit')); res.innerHTML = '';
          H.later(sl, paint, 700 + (+row.dataset.i) * 70);
        } else paint();
      });
      sl._lastEval = resultV;
      const scores = () => {
        $$('.lb-score', box).forEach((e) => { e.textContent = resultV < 0 ? '' : H.pct(rate(e.dataset.s, resultV), 0); });
        this.drawChart(sl, Math.min(ev, 4));
      };
      if (evalAnim) {
        $$('.lb-score', box).forEach((e) => { e.textContent = '…'; });
        this.drawChart(sl, ev - 1);
        H.later(sl, scores, 700 + Q.length * 70 + 200);
      } else scores();
      sl._best.classList.toggle('on', s >= 6);
      sl._bestT.classList.toggle('on', s >= 6);
      box.classList.toggle('overfit', s === 5);
    },
    leave(sl) { H.stopAll(sl); clearInterval(sl._auto); },
  });
})();
