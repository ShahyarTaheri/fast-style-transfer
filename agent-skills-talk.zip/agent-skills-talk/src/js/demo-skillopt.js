/* ==========================================================================
   Demo: SkillOpt, live — setup, training rounds, results.
   A scripted replay with illustrative numbers. The loop follows
   github.com/microsoft/SkillOpt, described in plain words:
   try (practice tasks) → review (failures) → edit (SKILL.md) → check (keep / discard).
   ========================================================================== */
(() => {
  'use strict';
  const H = window.DeckH;
  const $ = (s, r) => r.querySelector(s);
  const $$ = (s, r) => Array.from(r.querySelectorAll(s));
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const code = (s) => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>');

  /* ------------------------------------------------------------------ */
  /* ① a first-draft skill and 120 test questions                           */
  /* ------------------------------------------------------------------ */
  const SEED = `---
name: holdings-sql
description: Write SQL queries for
  the wealth data warehouse.
---

# Holdings SQL
Write a SQL query that answers the user's
question using tables in the \`wm\` schema.`;

  Deck.demo('seed', {
    init(sl) {
      $('.seedviz', sl).innerHTML =
        '<div class="sd">' +
        '<div class="sd-col"><div class="label">① the first draft · v0</div>' +
        '<div class="code sm"><div class="bar"><b>holdings-sql/SKILL.md</b><span>v0</span></div><pre data-lang="md"></pre></div>' +
        '<p class="body">Written in five minutes and never tested. It knows nothing about local currencies, snapshots or closed accounts.</p></div>' +
        '<div class="sd-col"><div class="label">② 120 questions with known answers</div>' +
        '<div class="sd-src" data-g="1"><span class="sd-chip">questions behind BI dashboards</span><span class="sd-chip">#data-help questions</span><span class="sd-chip hot">the 31 analyst corrections</span></div>' +
        '<div class="sd-ex card" data-g="2"><p class="label">example</p><p class="body">“Net flows by advisor team last quarter?”</p><p class="small mt-s">Answer: the result of a <b>reviewed</b> SQL query. The check compares <b>result tables</b>, not SQL text.</p></div>' +
        '</div>' +
        '<div class="sd-col sd-split"><div class="label">③ split them three ways</div>' +
        '<div class="sd-bins">' +
        '<div class="sd-bin" data-b="train"><div class="sd-bh"><b>60 practice</b><span class="small">it learns from these</span></div><div class="sd-dots"></div></div>' +
        '<div class="sd-bin" data-b="sel"><div class="sd-bh"><b>30 check</b><span class="small">decide keep or discard</span></div><div class="sd-dots"></div></div>' +
        '<div class="sd-bin" data-b="test"><div class="sd-bh"><b>30 final exam 🔒</b><span class="small">opened once, at the end</span></div><div class="sd-dots"></div></div>' +
        '</div>' +
        '<p class="lead sd-rule" data-g="4">The tool <mark class="hl-sweep">never sees</mark> the final exam.</p>' +
        '</div></div>';
      const pre = $('pre', sl);
      pre.innerHTML = Deck.highlight(SEED, 'md');
      const fill = (bin, n) => { $(`.sd-bin[data-b="${bin}"] .sd-dots`, sl).innerHTML = Array.from({ length: n }, () => '<i></i>').join(''); };
      fill('train', 60); fill('sel', 30); fill('test', 30);
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      $$('[data-g]', sl).forEach((e) => e.classList.toggle('on', s >= +e.dataset.g));
      $('.sd-split', sl).classList.toggle('on', s >= 3);
      const dots = $$('.sd-dots i', sl);
      if (s >= 3) {
        if (instant || sl._split) dots.forEach((d) => d.classList.add('in'));
        else dots.forEach((d, i) => H.later(sl, () => d.classList.add('in'), 120 + (i % 60) * 16 + Math.floor(i / 60) * 80));
        sl._split = true;
      } else { dots.forEach((d) => d.classList.remove('in')); sl._split = false; }
    },
    leave(sl) { H.stopAll(sl); },
  });

  /* ------------------------------------------------------------------ */
  /* ② training rounds                                                    */
  /* ------------------------------------------------------------------ */
  const BASE_LINES = [
    { t: '---', c: 'yfm' }, { t: 'name: holdings-sql', c: 'yfm' }, { t: 'description: Write SQL queries for the wealth data warehouse.', c: 'yfm' }, { t: '---', c: 'yfm' },
    { t: '# Holdings SQL', c: 'h' }, { t: 'Write a SQL query that answers the user\'s question using tables in the `wm` schema.', c: 'p' },
  ];
  const RULES = [
    { v: 1, sec: 'g', t: 'Exclude closed & test accounts: `status = \'OPEN\'`.' },
    { v: 1, sec: 'g', t: 'Values are in local currency: convert via `fx_rates`.' },
    { v: 1, sec: 'g', t: 'Positions are end-of-day snapshots: filter `as_of_date`.' },
    { v: 1, sec: 'g', t: 'AUM excludes held-away assets: `aum_eligible = true`.' },
    { v: 2, sec: 'g', t: '“Last quarter” = the calendar quarter-end snapshot.' },
    { v: 2, sec: 'g', t: 'One client: `household_id` = `hh_id` = `client_key`.' },
    { v: 2, sec: 'g', t: 'Net flows exclude internal journals (`JNL`).' },
    { v: 3, sec: 'g', t: 'Chain-link daily returns; never average monthly ones.' },
    { v: 3, sec: 'b', t: 'Check totals against `aum_daily_rollup`.' },
    { v: 4, sec: 'g', t: 'New clients = first funded date, not open date.' },
    { v: 4, sec: 'g', t: 'Count clients with `COUNT(DISTINCT household_id)`.' },
  ];

  const T = [
    { kind: 'setup' },
    { kind: 'baseline', score: 0.37 },
    { kind: 'round', n: 1, pass: 12, ver: 1, ok: true, from: 0.37, to: 0.60,
      review: ['closed & test accounts counted', 'EUR/GBP summed as USD', 'stale snapshot dates'],
      edits: ['Exclude closed & test accounts', 'Convert local currency via fx_rates', 'Filter the as_of_date snapshot', 'Exclude held-away assets from AUM'] },
    { kind: 'round', n: 2, pass: 17, ver: 1, ok: false, from: 0.60, to: 0.57, why: 'the “LIMIT 100” rule cut off grouped results',
      review: ['wrong quarter-end date', 'household_id vs client_key', 'journals counted as flows'],
      edits: ['“Last quarter” = quarter-end snapshot', 'Map household_id = client_key', 'Exclude internal journals', 'Always add LIMIT 100 to every query'],
      cand: ['“Last quarter” = the calendar quarter-end snapshot.', 'One client: `household_id` = `hh_id` = `client_key`.', 'Net flows exclude internal journals (`JNL`).', 'Always add LIMIT 100 to every query.'] },
    { kind: 'round', n: 3, pass: 19, ver: 2, ok: true, from: 0.60, to: 0.73,
      review: ['wrong quarter-end date', 'household_id vs client_key', 'journals counted as flows'],
      edits: ['“Last quarter” = quarter-end snapshot', 'Map household_id = client_key', 'Exclude internal journals'] },
    { kind: 'round', n: 4, pass: 21, ver: 3, ok: true, from: 0.73, to: 0.80,
      review: ['monthly returns averaged', 'totals differ from the BI dashboard'],
      edits: ['Chain-link daily returns', 'Check totals against aum_daily_rollup'] },
    { kind: 'round', n: 5, pass: 24, ver: 4, ok: true, from: 0.80, to: 0.87,
      review: ['new clients dated by open date', 'households double-counted'],
      edits: ['New clients = first funded date', 'COUNT(DISTINCT household_id)'] },
    { kind: 'round', n: 6, pass: 25, ver: 4, ok: false, from: 0.87, to: 0.87, why: 'no improvement, so nothing changes',
      review: ['percent formatting', 'running totals'],
      edits: ['Round percentages to 1 decimal', 'Prefer window functions for running totals'],
      cand: ['Round percentages to 1 decimal.', 'Prefer window functions for running totals.'] },
    { kind: 'exam', base: 0.40, fin: 0.87 },
  ];

  const versionAt = (s) => { let v = 0; for (let i = 0; i <= s && i < T.length; i++) if (T[i].ok) v = Math.max(v, T[i].ver); return v; };
  const scoreAt = (s) => { let sc = 0.37; for (let i = 2; i <= s && i < T.length; i++) if (T[i].ok) sc = T[i].to; return sc; };

  function docHTML(v, newV, cand, rej) {
    const lines = BASE_LINES.map((l) => `<div class="dl ${l.c}">${code(l.t)}</div>`);
    const g = RULES.filter((r) => r.sec === 'g' && r.v <= v);
    const b = RULES.filter((r) => r.sec === 'b' && r.v <= v);
    if (g.length || (cand && cand.length)) {
      lines.push(`<div class="dl h ${newV === 1 ? 'new' : ''}">## Gotchas</div>`);
      g.forEach((r) => lines.push(`<div class="dl li ${r.v === newV ? 'new' : ''}">- ${code(r.t)}</div>`));
      (cand || []).forEach((c) => lines.push(`<div class="dl li cand ${rej ? 'rej' : ''} ${/LIMIT|Round|window/.test(c) ? 'bad' : ''}">- ${code(c)}</div>`));
    }
    if (b.length) {
      lines.push(`<div class="dl h ${newV === 3 ? 'new' : ''}">## Before you answer</div>`);
      b.forEach((r) => lines.push(`<div class="dl li ${r.v === newV ? 'new' : ''}">- ${code(r.t)}</div>`));
    }
    return lines.join('');
  }

  Deck.demo('train', {
    init(sl) {
      $('.trainer', sl).innerHTML =
        '<div class="tr-top">' +
        '<div class="tr-stages">' + ['try', 'review', 'edit', 'check'].map((k) => `<span class="tr-sg" data-k="${k}">${k}</span>`).join('<i>→</i>') + '</div>' +
        '<div class="tr-ctl"><span class="tr-round mono"></span><button type="button" class="btn tr-auto">▶ Auto-run</button><button type="button" class="btn ghost tr-end">Skip to end</button><button type="button" class="btn ghost tr-reset">Reset</button></div>' +
        '</div>' +
        '<div class="tr-grid">' +
        '<div class="tr-doc"><div class="tr-doc-h"><span class="mono">SKILL.md</span><span class="tr-ver mono"></span></div><div class="tr-doc-b"></div></div>' +
        '<div class="tr-mid"></div>' +
        '<div class="tr-right"><div class="tr-score"><span class="label">check score</span><span class="num tr-big tnum">37%</span><span class="small">on the 30 check questions</span></div>' +
        '<div class="tr-chart"><svg viewBox="0 0 520 250" class="tr-svg" aria-label="Check score per round"></svg></div></div>' +
        '</div>';
      this.chartInit(sl);
      $('.tr-auto', sl).addEventListener('click', (e) => { e.currentTarget.blur(); this.autorun(sl); });
      $('.tr-end', sl).addEventListener('click', (e) => { e.currentTarget.blur(); clearInterval(sl._auto); Deck.go(Deck.cur, 8, { instant: true }); });
      $('.tr-reset', sl).addEventListener('click', (e) => { e.currentTarget.blur(); clearInterval(sl._auto); Deck.go(Deck.cur, 0, { instant: true }); });
    },
    autorun(sl) {
      clearInterval(sl._auto);
      if (Deck.step >= 8) Deck.go(Deck.cur, 0, { instant: true });
      const tick = () => { if (Deck.slides[Deck.cur] !== sl || Deck.step >= 8) { clearInterval(sl._auto); return; } Deck.next(); };
      tick();
      sl._auto = setInterval(tick, 5400);
    },
    chartInit(sl) {
      const svg = $('.tr-svg', sl);
      const L = 50, Tp = 24, W = 440, Hh = 180;
      const x = (i) => L + (i / 6) * W, y = (v) => Tp + (1 - (v - 0.3) / 0.6) * Hh;
      sl._x = x; sl._y = y;
      [0.3, 0.5, 0.7, 0.9].forEach((v) => {
        H.S('line', { x1: L, y1: y(v), x2: L + W, y2: y(v), cls: 'sv-grid' }, svg);
        H.S('text', { x: L - 10, y: y(v) + 5, 'text-anchor': 'end', cls: 'sv-tick mono', text: Math.round(v * 100) + '%' }, svg);
      });
      ['start', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6'].forEach((t, i) => H.S('text', { x: x(i), y: Tp + Hh + 24, 'text-anchor': 'middle', cls: 'sv-tick mono', text: t }, svg));
      sl._line = H.S('path', { cls: 'tr-bestline' }, svg);
      sl._pts = H.S('g', {}, svg);
      H.S('text', { x: L + W, y: Tp + Hh + 50, 'text-anchor': 'end', cls: 'sv-note', text: '● kept   ○ discarded' }, svg);
    },
    chart(sl, s) {
      const x = sl._x, y = sl._y;
      sl._pts.innerHTML = '';
      if (s < 1) { sl._line.setAttribute('d', ''); return; }
      let cur = 0.37;
      const pts = [[0, cur]];
      H.S('circle', { cx: x(0), cy: y(cur), r: 6, cls: 'tr-cand base' }, sl._pts);
      for (let i = 2; i <= Math.min(s, 7); i++) {
        const t = T[i];
        const xi = t.n;
        H.S('circle', { cx: x(xi), cy: y(t.to), r: 8, cls: 'tr-cand ' + (t.ok ? 'ok' : 'no') }, sl._pts);
        if (t.ok) cur = t.to;
        pts.push([xi, cur]);
      }
      sl._line.setAttribute('d', pts.map((p, i) => (i ? `H${x(p[0])} V${y(p[1])}` : `M${x(p[0])},${y(p[1])}`)).join(' '));
    },
    midHTML(t) {
      if (t.kind === 'setup') return '<div class="tr-card intro"><div class="h4">Ready</div><p class="body">60 practice · 30 check · 30 final exam (locked). The model stays the same; only SKILL.md changes.</p><p class="small mt-s">Press <b>→</b> for each round, or <b>Auto-run</b>.</p></div>';
      if (t.kind === 'baseline') return '<div class="tr-card"><div class="tr-h">starting point</div><div class="tr-big2 num">37%</div><p class="body">The first draft (v0) on the 30 check questions. Every edit must beat this.</p></div>';
      if (t.kind === 'exam') return '<div class="tr-card test"><div class="tr-h">final exam · opened once · 30 questions</div><div class="tr-test"><div><span class="label">start</span><div class="num u-fail">40%</div></div><i>→</i><div><span class="label">after 6 rounds</span><div class="num u-pass">87%</div></div></div><p class="body">Same model. One Markdown file changed.</p></div>';
      const dots = Array.from({ length: 30 }, (_, i) => {
        const fails = new Set(Array.from({ length: 30 - t.pass }, (_, k) => (k * 7 + t.n * 3) % 30));
        return `<i class="dot ${fails.has(i) ? 'f' : 'p'}"></i>`;
      }).join('');
      return `<div class="tr-sec" data-p="1"><div class="tr-h"><span>try · 30 practice tasks</span><span class="mono tr-v">${t.pass} ✓ · ${30 - t.pass} ✗</span></div><div class="tr-dots">${dots}</div></div>` +
        `<div class="tr-sec" data-p="2"><div class="tr-h">review · what went wrong</div><div class="tr-clusters">${t.review.map((c) => `<span class="tr-cl">${esc(c)}</span>`).join('')}</div></div>` +
        `<div class="tr-sec" data-p="3"><div class="tr-h">edit · proposed changes</div><div class="tr-edits">${t.edits.map((e) => `<div class="tr-edit ${/LIMIT|Round|window/.test(e) ? 'bad' : ''}">+ ${esc(e)}</div>`).join('')}</div></div>` +
        `<div class="tr-sec" data-p="4"><div class="tr-h">check · 30 check questions</div><div class="tr-gatev"><span class="mono">${Math.round(t.from * 100)}% → <b class="${t.ok ? 'u-pass' : 'u-fail'}">${Math.round(t.to * 100)}%</b></span><span class="${t.ok ? 'pill-pass' : 'pill-fail'}">${t.ok ? 'KEEP' : 'DISCARD'}</span></div>` +
        (t.ok ? '' : `<p class="small u-fail mt-s">${esc(t.why)}</p>`) + '</div>';
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      if (instant) clearInterval(sl._auto);
      const t = T[s];
      const mid = $('.tr-mid', sl), doc = $('.tr-doc-b', sl);
      $('.tr-round', sl).textContent = t.kind === 'round' ? `round ${t.n} of 6` : t.kind === 'exam' ? 'final exam' : t.kind === 'baseline' ? 'start' : 'ready';
      const setScore = (v) => { $('.tr-big', sl).textContent = Math.round(v * 100) + '%'; };
      const stages = (k) => $$('.tr-sg', sl).forEach((c) => { c.classList.toggle('cur', c.dataset.k === k); });
      const settle = () => {
        mid.innerHTML = this.midHTML(t);
        $$('.tr-sec', mid).forEach((e) => e.classList.add('in'));
        const v = versionAt(s);
        doc.innerHTML = docHTML(v, t.kind === 'round' && t.ok ? t.ver : -1);
        $('.tr-ver', sl).textContent = 'v' + v;
        setScore(t.kind === 'exam' ? scoreAt(7) : scoreAt(s));
        this.chart(sl, s);
        $$('.tr-sg', sl).forEach((c) => { c.classList.remove('cur'); c.classList.toggle('done', t.kind === 'round'); });
        doc.scrollTop = doc.scrollHeight;
      };
      if (instant || t.kind !== 'round') { settle(); return; }
      // animated round
      const prevV = versionAt(s - 1);
      doc.innerHTML = docHTML(prevV, -1);
      $('.tr-ver', sl).textContent = 'v' + prevV;
      setScore(t.from);
      this.chart(sl, s - 1);
      mid.innerHTML = this.midHTML(t);
      const secs = $$('.tr-sec', mid);
      $$('.tr-sg', sl).forEach((c) => c.classList.remove('cur', 'done'));
      stages('try'); secs[0].classList.add('in');
      $$('.tr-dots .dot', mid).forEach((d, i) => { d.classList.add('pending'); H.later(sl, () => d.classList.remove('pending'), 60 + i * 32); });
      H.later(sl, () => { stages('review'); secs[1].classList.add('in'); }, 1300);
      H.later(sl, () => {
        stages('edit'); secs[2].classList.add('in');
        doc.innerHTML = docHTML(prevV, -1, t.ok ? RULES.filter((r) => r.v === t.ver).map((r) => r.t) : t.cand);
        doc.scrollTop = doc.scrollHeight;
      }, 2200);
      H.later(sl, () => {
        stages('check'); secs[3].classList.add('in');
        H.animate(sl, 700, (k) => setScore(t.from + (t.to - t.from) * k));
        this.chart(sl, s);
        if (t.ok) {
          doc.innerHTML = docHTML(t.ver, t.ver);
          $('.tr-ver', sl).textContent = 'v' + t.ver;
        } else {
          $$('.dl.cand', doc).forEach((e) => e.classList.add('rej'));
          H.later(sl, () => { doc.innerHTML = docHTML(prevV, -1); setScore(t.from); }, 1300);
        }
        doc.scrollTop = doc.scrollHeight;
      }, 3200);
    },
    leave(sl) { H.stopAll(sl); clearInterval(sl._auto); },
  });

  /* ------------------------------------------------------------------ */
  /* ③ results                                                            */
  /* ------------------------------------------------------------------ */
  const LEARNED = [
    ['you included closed and test accounts', 'Exclude closed & test accounts: `status = \'OPEN\'`.'],
    ['those values are in EUR, not USD', 'Values are in local currency: convert via `fx_rates`.'],
    ['that\'s not the quarter-end snapshot', '“Last quarter” = the calendar quarter-end snapshot.'],
    ['AUM shouldn\'t include held-away assets', 'AUM excludes held-away assets: `aum_eligible = true`.'],
    ['household_id isn\'t client_key', 'One client: `household_id` = `hh_id` = `client_key`.'],
  ];
  Deck.demo('results', {
    init(sl) {
      $('.resviz', sl).innerHTML =
        '<div class="rs2">' +
        '<div class="rs2-l">' +
        '<div class="label">final exam · 30 questions it never saw</div>' +
        '<div class="rs-big"><div class="rs-b"><span class="mono">first draft</span><div class="rs-bar a"><i style="--w:40%"></i></div><span class="num tnum">40%</span></div>' +
        '<div class="rs-b"><span class="mono">after 6 rounds</span><div class="rs-bar b"><i style="--w:86.7%"></i></div><span class="num tnum u-pass">87%</span></div></div>' +
        '<p class="body">Same model. One Markdown file changed.</p>' +
        '</div>' +
        '<div class="rs2-r" data-r="2">' +
        '<div class="rs2-row rs2-hd"><span class="label">what analysts kept saying</span><span></span><span class="label">the rule SkillOpt added</span></div>' +
        LEARNED.map(([said, rule]) => `<div class="rs2-row rs2-item"><span class="rs2-said">“${esc(said)}”</span><i>→</i><span class="rs2-rule">${code(rule)}</span></div>`).join('') +
        '<p class="label rs2-more">+ 6 more short rules</p>' +
        '</div></div>' +
        '<div class="rs-foot" data-r="3"><p class="lead">It learned <mark class="hl-sweep static">your gotchas</mark>: the corrections your analysts kept typing.</p>' +
        '<p class="small mt-s"><b>Published results:</b> trained skills beat no skill in all 52 settings tested, +23.5 pts on average for GPT-5.5.</p></div>';
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      $('.rs-big', sl).classList.toggle('on', s >= 1);
      $$('[data-r]', sl).forEach((e) => e.classList.toggle('on', s >= +e.dataset.r));
      const rows = $$('.rs2-item', sl);
      if (!instant && s === 2) rows.forEach((r, i) => { r.classList.remove('in'); H.later(sl, () => r.classList.add('in'), 150 + i * 320); });
      else rows.forEach((r) => r.classList.toggle('in', s >= 2));
    },
    leave(sl) { H.stopAll(sl); },
  });
})();
