/* ==========================================================================
   Case study: Vercel's Next.js 16 evals, a docs skill vs an AGENTS.md index.
   Figures from vercel.com/blog/agents-md-outperforms-skills-in-our-agent-evals
   (Jan 2026). The "skill opened" squares show the reported share of runs.
   ========================================================================== */
(() => {
  'use strict';
  const H = window.DeckH;
  const $ = (s, r) => r.querySelector(s);
  const $$ = (s, r) => Array.from(r.querySelectorAll(s));

  /* ---------------- ① the scoreboard ---------------- */
  const CFG = [
    { k: 'no docs', sub: 'baseline', pass: 53, blt: [84, 95, 63], opened: null },
    { k: 'skill installed', sub: 'the agent decides', pass: 53, blt: [84, 89, 58], opened: 44 },
    { k: 'skill + “use it” line', sub: 'the line is in AGENTS.md', pass: 79, blt: [95, 100, 84], opened: 95 },
    { k: 'docs index in AGENTS.md', sub: 'no skill at all', pass: 100, blt: [100, 100, 100], opened: 'always' },
  ];
  const OBS = [
    'Four setups, one eval suite: build, lint and behaviour tests on Next.js 16 tasks, with repeated runs.',
    'With no docs, agents passed <b>53%</b>. They fell back on older Next.js patterns.',
    'The skill was <b>never opened in 56%</b> of runs. No gain at all, and slightly worse on tests (58% vs 63%): an unused skill is noise.',
    'A line in AGENTS.md telling the agent to use the skill: opened in <b>95%+</b> of runs, <b>79%</b> pass. But results swung with the exact wording.',
    'A compressed docs index in AGENTS.md, and no skill: <b>100%</b> on build, lint and test.',
    '<span class="vc-take">Same docs in every setup. What changed was <mark class="hl-sweep static">whether the agent had to decide</mark> to load them.</span>',
  ];

  Deck.demo('vcl', {
    init(sl) {
      const strip = (o) => (o === null ? '<span class="u-faint mono">—</span>'
        : o === 'always' ? '<span class="chip acc">always in context</span>'
        : '<span class="vc-sq">' + Array.from({ length: 20 }, (_, i) => `<i data-i="${i}"></i>`).join('') + '</span>');
      $('.vcl', sl).innerHTML =
        '<div class="vc">' +
        '<div class="vc-goal"><p class="lead">Goal: teach coding agents <b>Next.js 16</b> APIs they never saw in training.</p>' +
        '<div class="chips"><code class="i">\'use cache\'</code><code class="i">connection()</code><code class="i">forbidden()</code><code class="i">after()</code></div></div>' +
        '<div class="vc-board">' +
        '<div class="vc-row vc-hd"><span class="label">setup</span><span class="label">skill opened</span>' +
        '<span class="vc-hd-bar"><span class="label vc-hd-pass">pass rate</span><span class="vc-hd-blt label"><span>build</span><span>lint</span><span>test</span></span>' +
        '<span class="vc-tabs"><button type="button" data-v="pass" class="on">pass rate</button><button type="button" data-v="blt">build · lint · test</button></span></span>' +
        '<span></span><span class="label" style="text-align:right">vs no docs</span></div>' +
        CFG.map((c, i) => `<div class="vc-row${i === 3 ? ' best' : ''}" data-r="${i + 1}">` +
          `<div class="vc-k"><b>${c.k}</b><span class="label">${c.sub}</span></div>` +
          `<div class="vc-open">${strip(c.opened)}</div>` +
          '<div class="vc-bars"><div class="vc-bar"><i></i></div><div class="vc-blt">' +
          c.blt.map((v) => `<span><i style="--w:${v}%"></i><b>${v}%</b></span>`).join('') + '</div></div>' +
          '<div class="vc-v num tnum">–</div><div class="vc-d mono">–</div></div>').join('') +
        '</div>' +
        '<div class="vc-obs"><p class="body"></p></div>' +
        '</div>';
      sl._mode = 'pass';
      $$('.vc-tabs button', sl).forEach((b) => b.addEventListener('click', (e) => {
        e.currentTarget.blur();
        sl._mode = b.dataset.v;
        $$('.vc-tabs button', sl).forEach((x) => x.classList.toggle('on', x === b));
        $('.vc', sl).classList.toggle('blt', sl._mode === 'blt');
      }));
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      $$('.vc-row[data-r]', sl).forEach((row) => {
        const k = +row.dataset.r, c = CFG[k - 1];
        const on = s >= k, was = row.classList.contains('on');
        row.classList.toggle('on', on);
        const bar = $('.vc-bar i', row), v = $('.vc-v', row), d = $('.vc-d', row);
        const sq = $$('.vc-sq i', row);
        if (!on) {
          bar.style.width = '0'; row.classList.remove('lit');
          v.textContent = '–'; d.textContent = '–'; d.classList.remove('up');
          sq.forEach((q) => q.classList.remove('hit', 'miss'));
          return;
        }
        row.classList.add('lit');
        const delta = c.pass - CFG[0].pass;
        d.textContent = k === 1 ? '—' : (delta > 0 ? '+' : '±') + delta + ' pts';
        d.classList.toggle('up', delta > 0);
        const hits = typeof c.opened === 'number' ? Math.round(c.opened / 5) : 0;
        const paintSq = (q, i) => { q.classList.toggle('hit', i < hits); q.classList.toggle('miss', i >= hits); };
        if (instant || was) {
          bar.style.width = c.pass + '%';
          v.textContent = c.pass + '%';
          sq.forEach(paintSq);
          return;
        }
        sq.forEach((q) => q.classList.remove('hit', 'miss'));
        sq.forEach((q, i) => H.later(sl, () => paintSq(q, i), 80 + i * 45));
        const t0 = sq.length ? 80 + sq.length * 45 : 100;
        H.later(sl, () => {
          bar.style.width = c.pass + '%';
          H.animate(sl, 1000, (e) => { v.textContent = Math.round(c.pass * e) + '%'; });
        }, t0);
      });
      $('.vc-obs .body', sl).innerHTML = OBS[Math.min(s, OBS.length - 1)];
      $('.vc-obs', sl).classList.toggle('final', s >= 5);
    },
    leave(sl) { H.stopAll(sl); },
  });

  /* ---------------- ② one sentence apart ---------------- */
  const LANES = [
    { tag: 'A · skill first', ins: 'Invoke the skill before doing anything else.',
      acts: ['read the docs', 'write page.tsx'], files: [['page.tsx', 1], ['next.config.ts', 0]],
      obs: 'Anchored on the doc examples and missed the project context.' },
    { tag: 'B · project first', ins: 'Explore the project first, then use the skill.',
      acts: ['explore the project', 'read the docs', 'write page.tsx', 'update next.config.ts'], files: [['page.tsx', 1], ['next.config.ts', 1]],
      obs: 'Built a picture of the project first, then used the docs as a reference.' },
  ];
  Deck.demo('vcw', {
    init(sl) {
      $('.vcw', sl).innerHTML =
        '<div class="vw">' +
        '<p class="lead vw-intro">The task: add caching to a Next.js page. Done right, it takes <b>two edits</b>: the page and the config file.</p>' +
        '<div class="vw-lanes">' + LANES.map((l, i) =>
          `<div class="vw-lane" data-l="${i + 1}"><div class="row between center-y"><span class="kicker">${l.tag}</span><span class="label">line in AGENTS.md</span></div>` +
          `<div class="vw-ins mono">${l.ins}</div>` +
          '<ol class="vw-acts">' + l.acts.map((a, k) => `<li class="vw-act"><b>${k + 1}</b>${a}</li>`).join('') + '</ol>' +
          '<div class="vw-files">' + l.files.map(([f, ok]) => `<span class="vw-file" data-ok="${ok}">${f}</span>`).join('') + '</div>' +
          `<p class="vw-obs small">${l.obs}</p></div>`).join('') + '</div>' +
        '<p class="lead vw-take">If one sentence can swing the result, the setup is fragile. <mark class="hl-sweep static">Test your wording like code.</mark></p>' +
        '</div>';
    },
    play(sl, lane, instant) {
      const acts = $$('.vw-act', lane), files = $$('.vw-file', lane), obs = $('.vw-obs', lane);
      const paintFile = (f) => { const ok = f.dataset.ok === '1'; f.classList.add(ok ? 'ok' : 'no'); f.textContent = (ok ? '✓ ' : '✗ ') + f.textContent.replace(/^[✓✗] /, '') + (ok ? '' : ' missed'); };
      const reset = () => {
        acts.forEach((a) => a.classList.remove('lit'));
        files.forEach((f) => { f.classList.remove('ok', 'no'); f.textContent = f.textContent.replace(/^[✓✗] /, '').replace(/ missed$/, ''); });
        obs.classList.remove('on');
      };
      reset();
      if (instant) { acts.forEach((a) => a.classList.add('lit')); files.forEach(paintFile); obs.classList.add('on'); return; }
      acts.forEach((a, i) => H.later(sl, () => a.classList.add('lit'), 250 + i * 650));
      const t = 250 + acts.length * 650;
      files.forEach((f, i) => H.later(sl, () => paintFile(f), t + i * 350));
      H.later(sl, () => obs.classList.add('on'), t + files.length * 350 + 200);
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      $$('.vw-lane', sl).forEach((lane) => {
        const k = +lane.dataset.l;
        const on = s >= k, was = lane.classList.contains('on');
        lane.classList.toggle('on', on);
        if (!on) { this.play(sl, lane, true); $$('.vw-act', lane).forEach((a) => a.classList.remove('lit')); $$('.vw-file', lane).forEach((f) => { f.classList.remove('ok', 'no'); f.textContent = f.textContent.replace(/^[✓✗] /, '').replace(/ missed$/, ''); }); $('.vw-obs', lane).classList.remove('on'); return; }
        if (instant || was) this.play(sl, lane, true);
        else this.play(sl, lane, false);
      });
      $('.vw-take', sl).classList.toggle('on', s >= 3);
    },
    leave(sl) { H.stopAll(sl); },
  });
})();
