/* ==========================================================================
   Shared demo helpers + the lighter-weight demos
   ========================================================================== */
(() => {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const H = {
    S(tag, attrs = {}, parent) {
      const el = document.createElementNS(NS, tag);
      for (const k in attrs) {
        const v = attrs[k];
        if (v === undefined || v === null) continue;
        if (k === 'text') el.textContent = v;
        else if (k === 'cls') el.setAttribute('class', v);
        else el.setAttribute(k, v);
      }
      if (parent) parent.appendChild(el);
      return el;
    },
    E(tag, cls, html, parent) {
      const el = document.createElement(tag);
      if (cls) el.className = cls;
      if (html !== undefined && html !== null) el.innerHTML = html;
      if (parent) parent.appendChild(el);
      return el;
    },
    later(sl, fn, ms) {
      sl._timers = sl._timers || new Set();
      const t = setTimeout(() => { sl._timers.delete(t); fn(); }, ms);
      sl._timers.add(t);
      return t;
    },
    animate(sl, dur, fn, done) {
      sl._anims = sl._anims || new Set();
      const h = { stop: false };
      sl._anims.add(h);
      const t0 = performance.now();
      const ease = (t) => 1 - Math.pow(1 - t, 3);
      const tick = (now) => {
        if (h.stop) return;
        const t = Math.min(1, (now - t0) / dur);
        fn(ease(t), t);
        if (t < 1) requestAnimationFrame(tick);
        else { sl._anims.delete(h); if (done) done(); }
      };
      if (dur <= 0 || Deck.reduced) { fn(1, 1); sl._anims.delete(h); if (done) done(); return h; }
      requestAnimationFrame(tick);
      return h;
    },
    stopAll(sl) {
      if (sl._timers) { sl._timers.forEach(clearTimeout); sl._timers.clear(); }
      if (sl._anims) { sl._anims.forEach((h) => { h.stop = true; }); sl._anims.clear(); }
    },
    fmt(n, d = 0) { return Number(n).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }); },
    pct(x, d = 0) { return (x * 100).toFixed(d) + '%'; },
  };
  window.DeckH = H;
  const $ = (s, r) => r.querySelector(s);
  const $$ = (s, r) => Array.from(r.querySelectorAll(s));

  /* ---------------- title ---------------- */
  Deck.demo('title', {
    render(sl, s, { instant }) {
      H.stopAll(sl);
      const marks = $$('.tm', sl);
      if (instant || sl._litOnce) { marks.forEach((m) => m.classList.add('lit')); return; }
      marks.forEach((m) => m.classList.remove('lit'));
      marks.forEach((m, i) => H.later(sl, () => m.classList.add('lit'), 450 + i * 420));
      sl._litOnce = true;
    },
    leave(sl) { H.stopAll(sl); },
  });

  /* ---------------- flywheel ---------------- */
  const CYCLES = {
    flywheel: { nodes: ['ship', 'watch', 'spot', 'collect', 'fix', 'check'], center: ['every correction', 'is a test case'], final: 'every turn is checked' },
  };
  Deck.demo('cycle', {
    init(sl) {
      const cfg = CYCLES[sl.dataset.cycle || 'flywheel'];
      const svg = $('.cycle-svg', sl);
      const cx = 380, cy = 310, R = 228, r = 66;
      const n = cfg.nodes.length;
      const id = 'ah' + sl._idx;
      const defs = H.S('defs', {}, svg);
      [['', 'cy-ah'], ['on', 'cy-ah on']].forEach(([suf, cls]) => {
        const mk = H.S('marker', { id: id + suf, viewBox: '0 0 10 10', refX: 7, refY: 5, markerWidth: 7, markerHeight: 7, orient: 'auto-start-reverse' }, defs);
        H.S('path', { d: 'M0,0 L10,5 L0,10 z', cls }, mk);
      });
      H.S('circle', { cx, cy, r: R, cls: 'cy-ring' }, svg);
      const ang = (i) => -Math.PI / 2 + (i * 2 * Math.PI) / n;
      const gap = Math.asin((r + 12) / R);
      sl._arcs = [];
      for (let i = 0; i < n; i++) {
        const a0 = ang(i) + gap, a1 = ang(i + 1) - gap;
        const p = H.S('path', { d: `M${cx + R * Math.cos(a0)},${cy + R * Math.sin(a0)} A${R},${R} 0 0 1 ${cx + R * Math.cos(a1)},${cy + R * Math.sin(a1)}`, cls: 'cy-arc', 'marker-end': `url(#${id})` }, svg);
        sl._arcs.push(p);
      }
      sl._nodes = cfg.nodes.map((name, i) => {
        const x = cx + R * Math.cos(ang(i)), y = cy + R * Math.sin(ang(i));
        const g = H.S('g', { cls: 'cy-node' }, svg);
        H.S('circle', { cx: x, cy: y, r }, g);
        H.S('text', { x, y: y + 8, 'text-anchor': 'middle', cls: 'cy-lbl mono', text: name }, g);
        return g;
      });
      H.S('text', { x: cx, y: cy - 8, 'text-anchor': 'middle', cls: 'cy-center', text: cfg.center[0] }, svg);
      H.S('text', { x: cx, y: cy + 28, 'text-anchor': 'middle', cls: 'cy-center', text: cfg.center[1] }, svg);
      sl._final = H.S('text', { x: cx, y: cy + 68, 'text-anchor': 'middle', cls: 'cy-final mono', text: cfg.final }, svg);
      sl._n0 = n;
      sl._spin = H.S('circle', { cx, cy, r: R + 24, cls: 'cy-spin' }, svg);
    },
    render(sl, s) {
      const n = sl._n0, all = s > n;
      sl._nodes.forEach((g, i) => { g.classList.toggle('cur', !all && s === i + 1); g.classList.toggle('done', all || s > i + 1); });
      sl._arcs.forEach((p, i) => {
        const on = all || s > i + 1;
        p.classList.toggle('on', on);
        p.setAttribute('marker-end', `url(#ah${sl._idx}${on ? 'on' : ''})`);
      });
      $$('.cycle-legend .cl', sl).forEach((cl) => { const k = +cl.dataset.k; cl.classList.toggle('on', all || s >= k); cl.classList.toggle('cur', !all && s === k); });
      sl._final.classList.toggle('show', all);
      sl._spin.classList.toggle('show', all);
    },
  });

  /* ---------------- progressive disclosure ---------------- */
  Deck.demo('disclosure', {
    init(sl) {
      const svg = $('.ctx-svg', sl);
      H.S('text', { x: 0, y: 24, cls: 'sv-label big mono', text: '40 skills installed' }, svg);
      sl._tiles = [];
      const cols = 8, tw = 50, th = 64, gx = 12, gy = 14, oy = 44;
      for (let i = 0; i < 40; i++) {
        const x = (i % cols) * (tw + gx), y = oy + Math.floor(i / cols) * (th + gy);
        const g = H.S('g', { cls: 'dz-tile' }, svg);
        H.S('rect', { x, y, width: tw, height: th, rx: 5, cls: 'dz-body' }, g);
        H.S('rect', { x, y, width: tw, height: 14, rx: 5, cls: 'dz-meta' }, g);
        sl._tiles.push(g);
      }
      sl._hero = sl._tiles[10];
      H.S('text', { x: 0, y: 480, cls: 'dz-saved', text: '39 skill bodies never load' }, svg);
      const bx = 560, by = 40, bw = 170, bh = 560, max = 20000;
      H.S('text', { x: bx, y: 24, cls: 'sv-label big mono', text: 'context window' }, svg);
      H.S('rect', { x: bx, y: by, width: bw, height: bh, rx: 8, cls: 'dz-frame' }, svg);
      const segs = [
        { label: 'system prompt + chat', tok: 7800, cls: 'dz-s0', t: 0 },
        { label: '40 descriptions', tok: 4000, cls: 'dz-s1', t: 1 },
        { label: 'custodian-statements/SKILL.md', tok: 2800, cls: 'dz-s2', t: 2 },
        { label: 'references/CUSTODIANS.md', tok: 1900, cls: 'dz-s3', t: 3 },
        { label: 'extract.py → output only', tok: 250, cls: 'dz-s3', t: 3 },
      ];
      let y = by + bh, lastLy = Infinity;
      sl._segs = segs.map((sg) => {
        const h = Math.max(6, (sg.tok / max) * bh);
        y -= h;
        const mid = y + h / 2;
        const ly = Math.min(mid, lastLy - 56);
        lastLy = ly;
        const g = H.S('g', { cls: 'dz-seg ' + sg.cls }, svg);
        H.S('rect', { x: bx + 4, y: y + 1, width: bw - 8, height: h - 2, rx: 4 }, g);
        H.S('path', { d: `M${bx + bw + 4},${mid} L${bx + bw + 16},${mid} L${bx + bw + 30},${ly}`, cls: 'dz-lead' }, g);
        H.S('text', { x: bx + bw + 36, y: ly + 6, cls: 'dz-seg-l', text: sg.label }, g);
        H.S('text', { x: bx + bw + 36, y: ly + 30, cls: 'dz-seg-v mono', text: '+' + H.fmt(sg.tok) + ' tokens' }, g);
        return Object.assign(sg, { g });
      });
    },
    render(sl, s) {
      sl._tiles.forEach((t) => { t.classList.toggle('meta', s >= 1); t.classList.toggle('dim', s >= 2 && t !== sl._hero); });
      sl._hero.classList.toggle('hero', s >= 2);
      sl._segs.forEach((sg) => sg.g.classList.toggle('on', s >= sg.t));
      $('.dz-saved', sl).classList.toggle('on', s >= 4);
      $$('.tier', sl).forEach((t) => { const k = +t.dataset.t; t.classList.toggle('lit', s >= k || s === 0); t.classList.toggle('cur', s === k); });
    },
  });

  /* ---------------- how long should a skill be (log scale, 10 → 100k tokens) ---------------- */
  Deck.demo('lengths', {
    init(sl) {
      const svg = $('.len-svg', sl);
      const x0 = 70, x1 = 1530, ax = 282;
      const lx = (t) => x0 + ((Math.log10(t) - 1) / 4) * (x1 - x0);
      // budgets as a staircase: each tier loads later than the one above it
      const band = (a, b, row, cls, label, note, side) => {
        const g = H.S('g', { cls: 'ln-band ' + cls }, svg);
        const y = 24 + row * 76;
        H.S('rect', { x: lx(a), y, width: lx(b) - lx(a), height: 56, rx: 8 }, g);
        H.S('text', { x: lx(a) + 20, y: y + 37, cls: 'ln-band-l', text: label }, g);
        H.S('text', side === 'left'
          ? { x: lx(a) - 18, y: y + 36, 'text-anchor': 'end', cls: 'ln-band-n', text: note }
          : { x: lx(b) + 18, y: y + 36, cls: 'ln-band-n', text: note }, g);
        return g;
      };
      sl._b1 = band(10, 256, 0, 'b-desc', 'description', '≤ 1,024 chars ≈ 250 tokens · in every session');
      sl._b2 = band(256, 5000, 1, 'b-body', 'SKILL.md body', '< 5,000 tokens · < 500 lines', 'left');
      sl._b3 = band(5000, 100000, 2, 'b-ref', 'references/ · scripts/', 'loaded only when needed', 'left');
      // axis
      H.S('line', { x1: x0, y1: ax, x2: x1, y2: ax, cls: 'ln-axis' }, svg);
      [10, 30, 100, 300, 1000, 3000, 10000, 30000, 100000].forEach((t) => {
        const major = String(t)[0] === '1';
        H.S('line', { x1: lx(t), y1: ax - (major ? 9 : 5), x2: lx(t), y2: ax + (major ? 9 : 5), cls: 'ln-axis' }, svg);
        if (major) H.S('text', { x: lx(t), y: ax + 36, 'text-anchor': 'middle', cls: 'sv-tick mono', text: t >= 1000 ? t / 1000 + 'k' : String(t) }, svg);
      });
      H.S('text', { x: x1, y: ax + 64, 'text-anchor': 'end', cls: 'sv-note', text: 'tokens (log scale)' }, svg);
      // real skills on the same scale (step 3)
      sl._ex = H.S('g', { cls: 'ln-ex' }, svg);
      H.S('rect', { x: lx(300), y: ax - 8, width: lx(2000) - lx(300), height: 16, rx: 8, cls: 'ln-range' }, sl._ex);
      H.S('text', { x: (lx(300) + lx(2000)) / 2, y: ax - 22, 'text-anchor': 'middle', cls: 'ln-range-t', text: 'SkillOpt-trained skills: 300–2,000' }, sl._ex);
      const pin = (t, label, row, anchor) => {
        const ly = ax + 76 + row * 40;
        H.S('line', { x1: lx(t), y1: ax + 12, x2: lx(t), y2: ly - 20, cls: 'ln-stem' }, sl._ex);
        H.S('circle', { cx: lx(t), cy: ax, r: 10, cls: 'ln-pin' }, sl._ex);
        H.S('text', { x: lx(t) + (anchor === 'end' ? 6 : -6), y: ly, 'text-anchor': anchor, cls: 'ln-pin-l', text: label }, sl._ex);
      };
      pin(150, 'grill-me ≈ 150', 0, 'end');
      pin(400, 'frontend-design ≈ 400', 1, 'start');
      pin(1800, 'typical skill ≈ 1,800', 0, 'start');
    },
    render(sl, s) {
      sl._b1.classList.toggle('on', s >= 1);
      sl._b2.classList.toggle('on', s >= 2);
      sl._b3.classList.toggle('on', s >= 2);
      sl._ex.classList.toggle('on', s >= 3);
    },
  });

  /* ---------------- control vs risk: light the level being shown ---------------- */
  Deck.demo('freedom', {
    render(sl, s) {
      const n = Math.min(s, 3);
      $$('.ctl-node', sl).forEach((e) => { const k = +e.dataset.n; e.classList.toggle('on', n >= k); e.classList.toggle('cur', n === k); });
      // node centres sit in the middle of each of three grid columns (1.6rem gaps)
      const at = ['0%', 'calc((100% - 3.2rem) / 6)', '50%', 'calc(100% - (100% - 3.2rem) / 6)'];
      $('.ctl-fill', sl).style.width = at[n];
    },
  });

  /* ---------------- trigger test results ---------------- */
  Deck.demo('confusion', {
    init(sl) {
      $('.cm', sl).innerHTML =
        '<div class="cm-grid">' +
        '<div></div><div class="cm-h mono">skill fired</div><div class="cm-h mono">didn\'t fire</div>' +
        '<div class="cm-r mono">should fire<br><span>10 requests</span></div>' +
        '<div class="cm-c tp"><b class="tnum">–</b><span>✓ fired</span><div class="cm-dots"></div></div>' +
        '<div class="cm-c fn"><b class="tnum">–</b><span>✗ missed</span><div class="cm-dots"></div></div>' +
        '<div class="cm-r mono">should not<br><span>10 requests</span></div>' +
        '<div class="cm-c fp"><b class="tnum">–</b><span>✗ false alarm</span><div class="cm-dots"></div></div>' +
        '<div class="cm-c tn"><b class="tnum">–</b><span>✓ ignored</span><div class="cm-dots"></div></div>' +
        '</div><p class="cm-cap mono">description: “Generate reports.”</p>' +
        '<p class="cm-sum lead">Fired on only <b>5 of 10</b> it should, and on <b class="u-fail">4 of 10</b> it shouldn\'t.</p>';
      sl._cells = { tp: 5, fn: 5, fp: 4, tn: 6 };
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      const fill = s >= 2;
      Object.entries(sl._cells).forEach(([k, v], idx) => {
        const cell = $('.cm-c.' + k, sl);
        const dots = $('.cm-dots', cell);
        $('b', cell).textContent = fill ? v : '–';
        dots.innerHTML = '';
        if (!fill) return;
        for (let i = 0; i < v; i++) {
          const d = H.E('i', 'cm-dot', null, dots);
          if (instant) d.classList.add('in');
          else H.later(sl, () => d.classList.add('in'), 120 + idx * 160 + i * 90);
        }
      });
      $('.cm-sum', sl).classList.toggle('on', s >= 3);
    },
    leave(sl) { H.stopAll(sl); },
  });

  /* ---------------- with vs without the skill ---------------- */
  const WITHOUT = [0, 1, 0, 0, 1, 0, 0, 1, 0, 0];
  const WITH = [1, 1, 1, 0, 1, 1, 1, 1, 0, 1];
  Deck.demo('abtest', {
    init(sl) {
      const dots = (arr, k) => arr.map((v, i) => `<i class="ab-dot" data-v="${v}" data-i="${i}"></i>`).join('');
      $('.abtest', sl).innerHTML =
        '<div class="ab">' +
        '<div class="ab-tests card"><div class="label">10 test requests, e.g.</div>' +
        '<p class="ab-q">“Q3 review for household 88213 vs 60/40”</p>' +
        '<p class="ab-q">“YTD performance for the Johnson trust”</p>' +
        '<p class="ab-q">“why did the Chen IRA lag in September?”</p>' +
        '<p class="label">… and 7 more</p>' +
        '<div class="ab-must"><div class="label">a correct answer must show</div><ul class="checks sm"><li>time-weighted return</li><li>same-period benchmark</li><li>values in USD</li></ul></div></div>' +
        '<div class="ab-runs">' +
        '<div class="ab-row" data-r="1"><span class="ab-k">without skill</span><div class="ab-dots">' + dots(WITHOUT) + '</div><span class="ab-score num tnum">3 / 10</span></div>' +
        '<div class="ab-row" data-r="2"><span class="ab-k">with skill</span><div class="ab-dots">' + dots(WITH) + '</div><span class="ab-score num tnum u-pass">8 / 10</span></div>' +
        '<div class="ab-delta" data-r="3"><span class="num">+50 pts</span><span class="body">That\'s the claim, measured.</span></div>' +
        '<div class="ab-cost" data-r="4"><span class="body">It costs <b>+13 s</b> and <b>+1,700 tokens</b> per request.</span><span class="chip pass">worth it</span></div>' +
        '</div></div>';
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      $$('[data-r]', sl).forEach((row) => {
        const k = +row.dataset.r;
        const on = s >= k;
        const was = row.classList.contains('on');
        row.classList.toggle('on', on);
        const dots = $$('.ab-dot', row);
        if (!dots.length) return;
        if (!on) { dots.forEach((d) => d.classList.remove('p', 'f')); return; }
        if (instant || was) { dots.forEach((d) => d.classList.add(d.dataset.v === '1' ? 'p' : 'f')); return; }
        dots.forEach((d, i) => H.later(sl, () => d.classList.add(d.dataset.v === '1' ? 'p' : 'f'), 150 + i * 120));
      });
    },
    leave(sl) { H.stopAll(sl); },
  });

  /* ---------------- run it more than once ---------------- */
  const RUNS = [
    { t: 'Q3 review · household 88213', r: [1, 1, 1, 1, 1], v: 'reliable', c: 'pass' },
    { t: 'why the Garcia growth sleeve lagged', r: [1, 0, 1, 1, 0], v: 'flaky: unclear instructions', c: 'warn' },
    { t: 'Chen IRA return since inception', r: [0, 0, 0, 0, 0], v: 'broken: missing knowledge', c: 'fail' },
  ];
  Deck.demo('runs', {
    init(sl) {
      $('.runs', sl).innerHTML =
        '<div class="rn-head"><span class="label">test</span><span class="label">5 runs of the same request</span><span class="label">verdict</span></div>' +
        RUNS.map((x, k) => `<div class="rn-row" data-r="${k + 1}"><span class="rn-t">${x.t}</span><span class="rn-boxes">` +
          x.r.map((v) => `<i class="rn-box" data-v="${v}"></i>`).join('') + `</span><span class="chip ${x.c}">${x.v}</span></div>`).join('') +
        '<div class="rn-stat" data-r="4"><div class="rn-math">' +
        [1, 2, 3].map((k) => `<span class="rn-f"><b class="num tnum">75%</b><span class="label">run ${k} passes</span></span><i>${k < 3 ? '×' : '='}</i>`).join('') +
        '<span class="rn-f res"><b class="num tnum">42%</b><span class="label">all 3 pass</span></span></div>' +
        '<div class="rn-why"><p class="rn-dec mono">0.75 × 0.75 × 0.75 = 0.42</p><p class="body">A skill that passes <b>75%</b> of the time passes <b>3 runs in a row</b> only <b>42%</b> of the time.</p></div></div>';
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      $$('[data-r]', sl).forEach((row) => {
        const on = s >= +row.dataset.r;
        const was = row.classList.contains('on');
        row.classList.toggle('on', on);
        const boxes = $$('.rn-box', row);
        if (!boxes.length) return;
        if (!on) { boxes.forEach((b) => { b.classList.remove('p', 'f'); b.textContent = ''; }); return; }
        const paint = (b) => { const ok = b.dataset.v === '1'; b.classList.add(ok ? 'p' : 'f'); b.textContent = ok ? '✓' : '✗'; };
        if (instant || was) { boxes.forEach(paint); return; }
        boxes.forEach((b, i) => H.later(sl, () => paint(b), 200 + i * 220));
      });
    },
    leave(sl) { H.stopAll(sl); },
  });

  /* ---------------- gate chart ---------------- */
  Deck.demo('gatechart', {
    init(sl) {
      const svg = $('.gc-svg', sl);
      const L = 80, T = 30, W = 740, Hh = 420;
      const x = (i) => L + (i / 5) * W;
      const y = (v) => T + (1 - v / 0.7) * Hh;
      for (let v = 0; v <= 0.7001; v += 0.1) {
        H.S('line', { x1: L, y1: y(v), x2: L + W, y2: y(v), cls: 'sv-grid' }, svg);
        H.S('text', { x: L - 14, y: y(v) + 6, 'text-anchor': 'end', cls: 'sv-tick mono', text: Math.round(v * 100) + '%' }, svg);
      }
      for (let i = 0; i <= 5; i++) H.S('text', { x: x(i), y: T + Hh + 34, 'text-anchor': 'middle', cls: 'sv-tick mono', text: i === 0 ? 'start' : 'round ' + i }, svg);
      H.S('text', { x: L, y: T - 10, cls: 'sv-note', text: 'accuracy on held-out questions · one round per night' }, svg);
      const series = (vals, cls) => {
        const g = H.S('g', { cls: 'gc-series ' + cls }, svg);
        const path = H.S('path', { d: vals.map((v, i) => (i ? 'L' : 'M') + x(i) + ',' + y(v)).join(' '), cls: 'gc-line' }, g);
        const dots = vals.map((v, i) => H.S('circle', { cx: x(i), cy: y(v), r: 8, cls: 'gc-dot' }, g));
        return { g, path, dots };
      };
      sl._ng = series([0.554, 0.490, 0.325, 0.031, 0.034, 0.026], 'nogate');
      sl._gt = series([0.570, 0.570, 0.570, 0.570, 0.570, 0.570], 'gated');
      sl._ngL = H.S('text', { x: x(5) - 6, y: y(0.026) - 26, 'text-anchor': 'end', cls: 'gc-tag nogate mono', text: 'no check: 55% → 3%' }, svg);
      sl._gtL = H.S('text', { x: x(5) - 6, y: y(0.57) - 26, 'text-anchor': 'end', cls: 'gc-tag gated mono', text: 'with check: no loss' }, svg);
    },
    reveal(sl, sr, on, instant) {
      sr.g.classList.toggle('on', on);
      const len = sr.path.getTotalLength();
      if (!on) { sr.path.style.strokeDasharray = len; sr.path.style.strokeDashoffset = len; sr.dots.forEach((e) => e.classList.remove('in')); sr._shown = false; return; }
      if (sr._shown) return;
      sr._shown = true;
      if (instant) {
        sr.path.style.transition = 'none'; sr.path.style.strokeDasharray = 'none'; sr.path.style.strokeDashoffset = 0;
        sr.dots.forEach((e) => e.classList.add('in'));
        return;
      }
      sr.path.style.transition = 'none';
      sr.path.style.strokeDasharray = len; sr.path.style.strokeDashoffset = len;
      sr.path.getBoundingClientRect();
      sr.path.style.transition = 'stroke-dashoffset 2.4s linear';
      sr.path.style.strokeDashoffset = 0;
      sr.dots.forEach((d, i) => H.later(sl, () => d.classList.add('in'), i * 470));
    },
    render(sl, s, { instant }) {
      this.reveal(sl, sl._ng, s >= 3, instant);
      this.reveal(sl, sl._gt, s >= 4, instant);
      sl._ngL.classList.toggle('on', s >= 3);
      sl._gtL.classList.toggle('on', s >= 4);
    },
    leave(sl) { H.stopAll(sl); },
  });

  /* ---------------- SkillOpt loop: one round, next to the file it edits ---------------- */
  const LOOP_FILE = [
    ['yfm', '---'], ['yfm', 'name: holdings-sql'], ['yfm', 'description: Write SQL queries for the'], ['yfm', '  wealth data warehouse.'], ['yfm', '---'],
    ['h', '# Holdings SQL'], ['p', 'Write a SQL query that answers the'], ['p', "user's question using the wm schema."],
  ];
  const LOOP_NEW = [['h', '## Gotchas'], ['li', '- Values are in local currency:'], ['li', '  convert via fx_rates.']];
  const LOOP_STEPS = [
    { t: 'Try', d: 'Run the agent on practice questions, using the current SKILL.md.',
      v: '<span class="lv-dots">' + [1, 1, 0, 1, 0, 1, 1, 0].map((p) => `<i class="dot ${p ? 'p' : 'f'}"></i>`).join('') + '</span><span class="lv-k mono">5 right · 3 wrong</span>' },
    { t: 'Review', d: 'A stronger model reads the wrong answers and finds what they have in common.',
      v: '<span class="lv-chip">all 3 added EUR to USD without converting</span>' },
    { t: 'Edit', d: 'It writes one small fix into SKILL.md.',
      v: '<span class="lv-add mono">+ Values are in local currency: convert via fx_rates.</span>' },
    { t: 'Check', d: 'Score the new file on different questions. Keep the fix only if the score goes up.',
      v: '<span class="lv-check mono">37% → 60%</span><span class="pill-pass">KEEP</span><span class="lv-k">a lower score would throw it away</span>' },
  ];
  Deck.demo('loop', {
    init(sl) {
      const line = ([c, txt], cls = '') => `<div class="dl ${c} ${cls}">${Deck.esc(txt)}</div>`;
      $('.loopviz', sl).innerHTML =
        '<div class="lp2">' +
        '<div class="tr-doc lp2-file"><div class="tr-doc-h"><span class="mono">holdings-sql/SKILL.md</span><span class="lp2-ver mono">v0</span></div>' +
        '<div class="tr-doc-b">' + LOOP_FILE.map((l) => line(l)).join('') + '<div class="lp2-new">' + LOOP_NEW.map((l) => line(l, 'new')).join('') + '</div></div></div>' +
        '<ol class="lp2-steps">' + LOOP_STEPS.map((st, i) =>
          `<li class="lp2-st" data-i="${i + 1}"><span class="lp2-n mono">${i + 1}</span><div><div class="lp2-t">${st.t}</div><p class="lp2-d">${st.d}</p><div class="lp2-v">${st.v}</div></div></li>`).join('') + '</ol>' +
        '</div>' +
        '<div class="lp-foot"><p class="lead"><b>↻ Repeat for a few rounds.</b> The model never changes; only this Markdown file does.</p></div>';
    },
    render(sl, s) {
      $$('.lp2-st', sl).forEach((e) => { const i = +e.dataset.i; e.classList.toggle('on', s >= i); e.classList.toggle('cur', s === i); });
      $('.lp2-new', sl).classList.toggle('on', s >= 3);
      const ver = $('.lp2-ver', sl);
      ver.textContent = s >= 4 ? 'v1 · kept' : s >= 3 ? 'v1 · proposed' : 'v0';
      ver.classList.toggle('kept', s >= 4);
      $('.lp-foot', sl).classList.toggle('on', s >= 5);
    },
  });
})();
