/* ==========================================================================
   Demo: how the agent decides (skill router)
   ========================================================================== */
(() => {
  'use strict';
  const H = window.DeckH;
  const $ = (s, r) => r.querySelector(s);
  const $$ = (s, r) => Array.from(r.querySelectorAll(s));
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const CSV_V0 = 'Generate reports.';
  const CSV_V2 = 'Build client portfolio performance reviews: time-weighted returns, benchmark comparison and attribution. Use when someone asks how an account or household performed or mentions returns or benchmarks, even without saying "report".';
  const SKILLS = [
    { k: 'day-count', d: 'Compute accrued interest and year fractions with the right day-count convention (30/360, ACT/360, ACT/365). Use for accrued interest, coupons or settlement amounts.' },
    { k: 'client-report', d: CSV_V0 },
    { k: 'custodian-statements', d: 'Extract holdings, transactions and cash from custodian statement PDFs (Schwab, Fidelity, Pershing). Use when reconciling accounts.' },
    { k: 'rebalance-check', d: 'Check proposed trades against target weights, drift bands and the restricted list. Use when preparing or reviewing a rebalance.' },
    { k: 'holdings-sql', d: 'Answer questions about holdings, AUM and flows with SQL against the wealth data warehouse.' },
  ];
  const STEPS = [
    null,
    { q: 'Accrued interest on a 4.25% corporate bond, Mar 1 to Jun 15, 30/360?', csv: 0, hl: { 'day-count': ['accrued interest', '30/360'] }, fire: 'day-count', kind: 'fire', tok: 210,
      note: 'The request matches the description, so the full SKILL.md loads.' },
    { q: 'the Hartleys want to know how their portfolio did vs the benchmark last quarter', csv: 0, hl: {}, fire: null, target: 'client-report', kind: 'miss', tok: 0,
      note: '“Generate reports.” says nothing about returns, benchmarks or how a portfolio did. <b>Missed</b>: the agent improvises without your house methodology.' },
    { q: 'the Hartleys want to know how their portfolio did vs the benchmark last quarter', csv: 2, hl: { 'client-report': ['how an account or household performed', 'benchmarks', 'even without saying "report"'] }, fire: 'client-report', kind: 'fire', tok: 2300,
      note: 'Same request, better description. It now names what people actually ask.' },
    { q: 'read this Schwab statement and tell me the account number', csv: 2, hl: { 'custodian-statements': ['Schwab'] }, fire: null, target: 'custodian-statements', kind: 'skip', tok: 0,
      note: 'The description matches, but the task is trivial. Agents open skills for work <b>beyond</b> what basic tools can do.' },
    { q: 'read this Schwab statement and tell me the account number', csv: 2, hl: {}, fire: null, kind: 'take', tok: 0, note: '' },
  ];

  function descHTML(text, phrases) {
    let html = esc(text);
    (phrases || []).forEach((p) => {
      const e = esc(p);
      html = html.replace(e, '<mark class="rt-hl">' + e + '</mark>');
    });
    return html;
  }

  Deck.demo('router', {
    init(sl) {
      const box = $('.router', sl);
      box.innerHTML =
        '<div class="rt">' +
        '<div class="rt-left">' +
        '<div class="rt-chat"><span class="label">user</span><div class="rt-q"><span class="rt-qt"></span><span class="rt-caret"></span></div></div>' +
        '<div class="rt-cat code"><div class="bar"><b>system prompt · &lt;available_skills&gt;</b><span>name + description only</span></div><div class="rt-list">' +
        SKILLS.map((s) => `<div class="rt-sk" data-k="${s.k}"><span class="rt-n">${s.k}</span><span class="rt-d"></span></div>`).join('') +
        '</div></div></div>' +
        '<div class="rt-right">' +
        '<div class="rt-dec"><span class="label">the model\'s next move</span><div class="rt-dec-v mono"></div><p class="rt-dec-n small"></p></div>' +
        '<div class="rt-ctx"><div class="row between"><span class="label">context used</span><span class="rt-ctx-v mono tnum"></span></div><div class="rt-ctx-bar"><i class="c-base"></i><i class="c-skill"></i></div></div>' +
        '<div class="rt-take"><p class="big" style="font-size:3.4rem">The description <mark class="hl-sweep static">is the trigger</mark>.</p></div>' +
        '</div><svg class="rt-link" aria-hidden="true"></svg></div>';
      sl._q = $('.rt-qt', box);
      window.addEventListener('resize', () => {
        if (Deck.slides[Deck.cur] === sl && sl._link) this.link(sl, sl._link.target, sl._link.kind, false);
      });
    },
    // request → skill connector: solid arrow when the skill loads, broken link when it doesn't
    link(sl, target, kind, animate) {
      const box = $('.router', sl), rt = $('.rt', box), svg = $('.rt-link', box);
      svg.innerHTML = '';
      sl._link = target && kind ? { target, kind } : null;
      if (!sl._link) return;
      const b = rt.getBoundingClientRect();
      const sc = b.width / (rt.offsetWidth || b.width) || 1;
      const q = $('.rt-q', box).getBoundingClientRect();
      const row = $(`.rt-sk[data-k="${target}"]`, box).getBoundingClientRect();
      const X = (v) => (v - b.left) / sc, Y = (v) => (v - b.top) / sc;
      const sx = X(q.left), sy = Y(q.top + q.height / 2);
      const tx = X(row.left) - 5, ty = Y(row.top + row.height / 2);
      const gx = sx - 34, r = 12;
      const g = H.S('g', { cls: 'rt-ln ' + kind }, svg);
      const draw = (el, ms) => {
        const L = el.getTotalLength();
        el.style.strokeDasharray = L; el.style.strokeDashoffset = L;
        el.getBoundingClientRect();
        el.style.transition = `stroke-dashoffset ${ms}ms cubic-bezier(.2,.7,.1,1)`;
        el.style.strokeDashoffset = 0;
      };
      if (kind === 'fire') {
        const path = H.S('path', { d: `M${sx},${sy} H${gx + r} Q${gx},${sy} ${gx},${sy + r} V${ty - r} Q${gx},${ty} ${gx + r},${ty} H${tx}`, cls: 'rt-ln-p' }, g);
        const head = H.S('path', { d: `M${tx - 12},${ty - 8} L${tx},${ty} L${tx - 12},${ty + 8}`, cls: 'rt-ln-h' }, g);
        if (animate) { draw(path, 700); head.style.opacity = 0; H.later(sl, () => { head.style.opacity = 1; }, 600); }
        return;
      }
      const mid = (sy + ty) / 2, gap = 15;
      const p1 = H.S('path', { d: `M${sx},${sy} H${gx + r} Q${gx},${sy} ${gx},${sy + r} V${mid - gap}`, cls: 'rt-ln-p' }, g);
      const p2 = H.S('path', { d: `M${gx},${mid + gap} V${ty - r} Q${gx},${ty} ${gx + r},${ty} H${tx}`, cls: 'rt-ln-p rt-ln-dead' }, g);
      const x = H.S('text', { x: gx, y: mid + 7, 'text-anchor': 'middle', cls: 'rt-ln-x', text: '✗' }, g);
      if (animate) {
        draw(p1, 450); p2.style.opacity = 0; x.style.opacity = 0;
        H.later(sl, () => { x.style.opacity = ''; }, 430);
        H.later(sl, () => { p2.style.opacity = ''; }, 650);
      }
    },
    show(sl, st, instant, catalogOnly) {
      const box = $('.router', sl);
      const cfg = STEPS[st];
      $$('.rt-sk', box).forEach((row) => {
        const k = row.dataset.k;
        const sk = SKILLS.find((x) => x.k === k);
        let text = sk.d;
        if (k === 'client-report') text = cfg && cfg.csv === 2 ? CSV_V2 : CSV_V0;
        const phrases = !catalogOnly && cfg && cfg.hl ? cfg.hl[k] : null;
        const fire = !catalogOnly && cfg ? cfg.fire : null;
        $('.rt-d', row).innerHTML = descHTML(text, phrases);
        const focus = !catalogOnly && cfg ? (cfg.fire || cfg.target) : null;
        row.classList.toggle('fire', !!fire && fire === k);
        row.classList.toggle('match', !!phrases);
        row.classList.toggle('dimmed', !!focus && focus !== k);
        row.classList.toggle('missed', !!focus && focus === k && cfg.kind === 'miss');
        row.classList.toggle('skipped', !!focus && focus === k && cfg.kind === 'skip');
        if (k === 'client-report') {
          const v = cfg ? cfg.csv : 0;
          if (row._csv !== undefined && row._csv !== v && !instant) { row.classList.remove('flash'); void row.offsetWidth; row.classList.add('flash'); }
          row._csv = v;
          $('.rt-n', row).innerHTML = 'client-report' + (v === 2 ? ' <span class="chip acc rt-v">v2</span>' : '');
        }
      });
      const dv = $('.rt-dec-v', box), dn = $('.rt-dec-n', box);
      dv.className = 'rt-dec-v mono';
      if (!cfg) { dv.innerHTML = '<span class="u-faint">waiting for a request…</span>'; dn.innerHTML = ''; }
      else if (catalogOnly) { dv.innerHTML = '<span class="u-faint">reading descriptions…</span>'; dn.innerHTML = ''; }
      else if (cfg.kind === 'take') { dv.innerHTML = ''; dn.innerHTML = ''; }
      else if (cfg.kind === 'fire') { dv.classList.add('fire'); dv.innerHTML = '✓ Skill("' + cfg.fire + '")'; dn.innerHTML = cfg.note; }
      else if (cfg.kind === 'miss') { dv.classList.add('miss'); dv.innerHTML = '✗ no skill loaded'; dn.innerHTML = cfg.note; }
      else { dv.classList.add('skip'); dv.innerHTML = '◦ answers with basic tools'; dn.innerHTML = cfg.note; }
      const base = 5600, tok = cfg && !catalogOnly ? cfg.tok : 0, max = 10000;
      $('.c-base', box).style.width = (base / max) * 100 + '%';
      $('.c-skill', box).style.width = (tok / max) * 100 + '%';
      $('.rt-ctx-v', box).textContent = H.fmt(base + tok) + ' tokens' + (tok ? '  (+' + H.fmt(tok) + ' SKILL.md)' : '');
      $('.rt-take', box).classList.toggle('on', st === 5);
      $('.rt-dec', box).classList.toggle('hide', st === 5);
      const target = cfg && !catalogOnly ? (cfg.fire || cfg.target) : null;
      const kind = cfg && ['fire', 'miss', 'skip'].includes(cfg.kind) ? cfg.kind : null;
      this.link(sl, target, kind, !instant);
    },
    render(sl, s, { instant }) {
      H.stopAll(sl);
      const cfg = STEPS[s];
      const box = $('.router', sl);
      const q = cfg ? cfg.q : '';
      const prevQ = sl._lastQ;
      sl._lastQ = q;
      box.classList.remove('thinking');
      if (instant || !cfg || cfg.kind === 'take') { sl._q.textContent = q; this.show(sl, s, instant, false); return; }
      const decide = () => {
        box.classList.add('thinking');
        H.later(sl, () => { box.classList.remove('thinking'); this.show(sl, s, false, false); }, 950);
      };
      this.show(sl, s, false, true);
      if (q === prevQ) { sl._q.textContent = q; H.later(sl, decide, 700); return; }
      sl._q.textContent = '';
      let i = 0;
      const tick = () => {
        i = Math.min(q.length, i + 2);
        sl._q.textContent = q.slice(0, i);
        if (i < q.length) H.later(sl, tick, 26);
        else decide();
      };
      H.later(sl, tick, 200);
    },
    leave(sl) { H.stopAll(sl); },
  });
})();
