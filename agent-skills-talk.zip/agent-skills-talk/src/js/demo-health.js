/* ==========================================================================
   Demo: skill health dashboard (illustrative data)
   ========================================================================== */
(() => {
  'use strict';
  const $ = (s, r) => r.querySelector(s);
  const $$ = (s, r) => Array.from(r.querySelectorAll(s));

  const ROWS = [
    { k: 'client-report', v: 'v7', uses: 312, corr: [3, 3, 4, 3, 2, 3, 3], st: 'ok' },
    { k: 'custodian-statements', v: 'v3', uses: 141, corr: [2, 1, 2, 3, 2, 2, 2], st: 'ok' },
    { k: 'rebalance-check', v: 'v3', uses: 88, corr: [6, 7, 5, 6, 6, 7, 6], st: 'ok' },
    { k: 'holdings-sql', v: 'v0', uses: 146, corr: [12, 15, 18, 19, 22, 23, 21], st: 'bad' },
    { k: 'kyc-docs', v: 'v2', uses: 97, corr: [5, 4, 6, 5, 5, 4, 5], st: 'ok' },
    { k: 'legacy-fix-parser', v: 'v1', uses: 0, corr: null, st: 'dead' },
  ];
  const CLUSTERS = [
    ['“you included closed and test accounts”', 9],
    ['“those values are in EUR, not USD”', 7],
    ['“that\'s not the quarter-end snapshot”', 6],
    ['“AUM shouldn\'t include held-away assets”', 5],
    ['“household_id isn\'t client_key”', 4],
  ];

  function spark(vals, w = 110, h = 30, cls = '') {
    const max = Math.max(...vals, 1);
    const pts = vals.map((v, i) => [(i / (vals.length - 1)) * (w - 6) + 3, h - 3 - (v / max) * (h - 8)]);
    const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
    const last = pts[pts.length - 1];
    return `<svg class="spark ${cls}" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" aria-hidden="true"><path d="${d} L${last[0]},${h - 2} L3,${h - 2} Z" class="sp-area"/><path d="${d}" class="sp-line"/><circle cx="${last[0]}" cy="${last[1]}" r="2.8" class="sp-end"/></svg>`;
  }

  Deck.demo('health', {
    init(sl) {
      $('.health', sl).innerHTML =
        '<div class="hl-wrap"><div class="hl-main">' +
        '<div class="hl-head"><span class="mono">skill health · last 7 days</span><span class="chip">illustrative data</span></div>' +
        '<table class="tbl hl-tbl"><tr><th>skill</th><th>uses / day</th><th>sessions corrected</th><th></th></tr>' +
        ROWS.map((r) => `<tr class="hl-r ${r.st}" data-k="${r.k}"><td><b class="mono">${r.k}</b> <span class="label">${r.v}</span></td>` +
          `<td class="tnum mono">${r.uses}</td>` +
          `<td>${r.corr ? '<span class="row keep center-y" style="gap:.8rem">' + spark(r.corr, 110, 30, r.st === 'bad' ? 'bad' : '') + '<span class="tnum mono">' + r.corr[6] + '%</span></span>' : '<span class="u-faint">–</span>'}</td>` +
          `<td>${r.st === 'bad' ? '<span class="chip fail">needs attention</span>' : r.st === 'dead' ? '<span class="chip warn">never used</span>' : '<span class="chip pass">healthy</span>'}</td></tr>`).join('') +
        '</table><p class="hl-note body"><b>holdings-sql v0</b> is a quick first draft: written in five minutes, never tested. Usage grew fast, and so did corrections.</p></div>' +
        '<div class="hl-side">' +
        '<div class="hl-panel hl-p1"><div class="label">what users said · 31 sessions</div><div class="hl-clusters">' +
        CLUSTERS.map(([t, n]) => `<div class="hl-c"><span class="hl-ct">${t}</span><span class="hl-cb"><i style="--w:${(n / 9) * 100}%"></i></span><span class="mono tnum">${n}</span></div>`).join('') +
        '</div></div>' +
        '<div class="hl-panel hl-p2"><div class="label">turned into test cases</div><div class="row keep end-y mt-s" style="gap:1.4rem"><div class="num u-fail" style="font-size:4rem">40%</div><p class="body">current skill on those tests.<br>Next: <b>let a tool fix it →</b></p></div></div>' +
        '</div></div>';
    },
    render(sl, s) {
      const box = $('.health', sl);
      box.classList.toggle('focus', s >= 1);
      $$('.hl-r', box).forEach((r) => r.classList.toggle('sel', s >= 1 && r.dataset.k === 'holdings-sql'));
      $('.hl-p1', box).classList.toggle('on', s >= 2);
      $('.hl-p2', box).classList.toggle('on', s >= 3);
      box.classList.toggle('side', s >= 2);
    },
  });
})();
