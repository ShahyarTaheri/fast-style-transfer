/* ==========================================================================
   Deck engine — slides, step reveals, demos, HUD, notes, TOC, keyboard.
   A slide's state is a pure function of (slide index, step), so moving
   backwards or jumping always lands in a consistent state.
   ========================================================================== */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const docMQ = matchMedia('(max-width: 760px)');
  const reduceMQ = matchMedia('(prefers-reduced-motion: reduce)');
  const store = {
    get(k) { try { return localStorage.getItem('stfwl:' + k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem('stfwl:' + k, v); } catch (e) { /* ignore */ } },
  };

  /* ---------------- syntax highlighter ---------------- */
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const R = (src, flags = '') => new RegExp(src, 'y' + flags);
  const RULES = {
    yaml: [
      [R('^---\\s*$'), 't-fence'],
      [R('#.*'), 't-com'],
      [R('^(\\s*-\\s+)?[A-Za-z_][\\w.-]*(?=\\s*:)'), 't-key'],
      [R('"(?:[^"\\\\]|\\\\.)*"|\'[^\']*\''), 't-str'],
      [R('\\b(?:true|false|null|yes|no)\\b'), 't-num'],
      [R('-?\\b\\d+(?:\\.\\d+)?\\b'), 't-num'],
      [R('[>|][-+]?\\s*$'), 't-kw'],
    ],
    md: [
      [R('^#{1,6} .*'), 't-head'],
      [R('^\\s*(?:[-*]|\\d+\\.)(?= )'), 't-kw'],
      [R('\\[[ x]\\]'), 't-num'],
      [R('`[^`]+`'), 't-str'],
      [R('\\*\\*[^*]+\\*\\*'), 't-bold'],
      [R('<!--.*?-->'), 't-com'],
      [R('\\$ARGUMENTS(?:\\[\\d+\\])?|\\$\\d'), 't-var'],
    ],
    json: [
      [R('"(?:[^"\\\\]|\\\\.)*"(?=\\s*:)'), 't-key'],
      [R('"(?:[^"\\\\]|\\\\.)*"'), 't-str'],
      [R('\\b(?:true|false|null)\\b'), 't-kw'],
      [R('-?\\b\\d+(?:\\.\\d+)?(?:e-?\\d+)?\\b'), 't-num'],
      [R('[{}\\[\\],:]'), 't-punc'],
    ],
    bash: [
      [R('^\\$ '), 't-prompt'],
      [R('^> '), 't-prompt'],
      [R('(?:^|(?<=\\s))#.*'), 't-com'],
      [R('"(?:[^"\\\\]|\\\\.)*"|\'[^\']*\''), 't-str'],
      [R('\\$\\{?[A-Za-z_@#?*][\\w]*\\}?|\\$\\(\\('), 't-var'],
      [R('(?<=\\s)--?[A-Za-z][\\w-]*'), 't-flag'],
      [R('\\b(?:if|then|else|fi|for|in|do|done|while|function|return|local)\\b'), 't-kw'],
    ],
    python: [
      [R('#.*'), 't-com'],
      [R('"""[^]*?"""|\'\'\'[^]*?\'\'\'|f?"(?:[^"\\\\]|\\\\.)*"|f?\'(?:[^\'\\\\]|\\\\.)*\''), 't-str'],
      [R('@[\\w.]+'), 't-fn'],
      [R('\\b(?:def|class|return|import|from|as|with|for|in|if|elif|else|while|not|and|or|is|None|True|False|lambda|yield|try|except|raise|pass)\\b'), 't-kw'],
      [R('(?<=\\bdef )\\w+'), 't-fn'],
      [R('\\b\\d+(?:\\.\\d+)?\\b'), 't-num'],
    ],
    sql: [
      [R('--.*'), 't-com'],
      [R("'[^']*'"), 't-str'],
      [R('\\b(?:SELECT|FROM|WHERE|JOIN|LEFT|INNER|ON|GROUP|BY|ORDER|LIMIT|AND|OR|NOT|NULL|IS|AS|SUM|COUNT|DISTINCT|CASE|WHEN|THEN|ELSE|END|IN|WITH|HAVING|ROUND|DATE_TRUNC|BETWEEN|DESC|ASC)\\b', 'i'), 't-kw'],
      [R('\\b\\d+(?:\\.\\d+)?\\b'), 't-num'],
    ],
    toml: [
      [R('#.*'), 't-com'],
      [R('^\\[.*\\]'), 't-head'],
      [R('^[\\w.-]+(?=\\s*=)'), 't-key'],
      [R('"(?:[^"\\\\]|\\\\.)*"'), 't-str'],
    ],
  };
  function hlLine(line, rules) {
    if (!rules) return esc(line);
    let out = '', i = 0, plain = '';
    const flush = () => { if (plain) { out += esc(plain); plain = ''; } };
    while (i < line.length) {
      let hit = null;
      for (const [re, cls] of rules) {
        re.lastIndex = i;
        const m = re.exec(line);
        if (m && m[0].length) { hit = [m[0], cls]; break; }
      }
      if (hit) { flush(); out += '<span class="' + hit[1] + '">' + esc(hit[0]) + '</span>'; i += hit[0].length; }
      else { plain += line[i]; i++; }
    }
    flush();
    return out;
  }
  function highlight(text, lang) {
    const lines = text.replace(/^\n/, '').replace(/\s+$/, '').split('\n');
    let inFm = false;
    return lines.map((ln, idx) => {
      let rules = RULES[lang];
      if (lang === 'md') {
        if (idx === 0 && /^---\s*$/.test(ln)) { inFm = true; return '<span class="ln"><span class="t-fence">---</span></span>'; }
        if (inFm) {
          if (/^---\s*$/.test(ln)) { inFm = false; return '<span class="ln"><span class="t-fence">---</span></span>'; }
          rules = RULES.yaml;
        }
      }
      const html = hlLine(ln, rules);
      return '<span class="ln">' + (html || ' ') + '</span>';
    }).join('');
  }
  function highlightAll(root) {
    $$('pre[data-lang]', root).forEach((pre) => {
      if (pre._hl) return;
      pre._hl = true;
      // hand-authored markup (typed terminals, cursors) is left untouched
      if (pre.querySelector('*')) return;
      pre.innerHTML = highlight(pre.textContent, pre.dataset.lang);
    });
  }

  /* ---------------- deck state ---------------- */
  const Deck = {
    slides: [], cur: 0, step: 0, demos: {}, chapters: [],
    doc: false, started: 0, timers: new Set(),
    demo(name, impl) { this.demos[name] = impl; },
    later(fn, ms) { const t = setTimeout(() => { this.timers.delete(t); fn(); }, ms); this.timers.add(t); return t; },
    clearTimers() { this.timers.forEach(clearTimeout); this.timers.clear(); },
    get reduced() { return reduceMQ.matches; },
    highlight, esc,
  };
  window.Deck = Deck;

  function parseFocus(spec) {
    // "1:1-3 2:4-6,9" -> {1:Set([1,2,3]), 2:Set([4,5,6,9])}
    const map = {};
    spec.trim().split(/\s+/).forEach((part) => {
      const [st, ranges] = part.split(':');
      const set = new Set();
      ranges.split(',').forEach((r) => {
        const [a, b] = r.split('-').map(Number);
        for (let x = a; x <= (b || a); x++) set.add(x);
      });
      map[+st] = set;
    });
    return map;
  }

  const CHAPS = ['primer', 'design', 'trigger', 'evaluate', 'observe', 'train'];

  function slug(s) {
    return (s || '').toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 42);
  }

  function prepSlide(sl, idx) {
    const els = $$('[data-step], .step', sl);
    // explicit data-step="n" places an element at build n; plain .step elements
    // are numbered 1, 2, 3… in DOM order by their own counter
    let max = 0, auto = 0;
    els.forEach((el) => {
      const ds = el.getAttribute('data-step');
      const n = ds !== null && ds !== '' ? +ds : ++auto;
      el._s = n; max = Math.max(max, n);
      const o = el.getAttribute('data-out');
      el._o = o ? +o : 0;
    });
    sl._els = els;
    sl._n = Math.max(max, +(sl.dataset.steps || 0));
    sl._focus = $$('[data-focus]', sl).map((pre) => ({ pre, map: parseFocus(pre.dataset.focus) }));
    sl._typers = $$('[data-type]', sl);
    sl._typers.forEach((el) => { el._full = el.textContent; });
    // typers outside any step play when the slide is entered
    sl._typers0 = sl._typers.filter((t) => !t.closest('[data-step], .step'));
    sl._idx = idx;
    // auto eyebrow + footer
    const title = sl.dataset.title || ($('.s-title', sl) || {}).textContent || '';
    sl._title = title.trim().replace(/\s+/g, ' ');
    const ch = sl.dataset.chapter || '';
    const eb = $('.s-eyebrow[data-auto]', sl);
    if (eb) {
      eb.innerHTML = '<b>' + Deck.esc(ch) + '/</b><span>' + Deck.esc(sl.dataset.slug || slug(sl._title)) + '</span>';
    }
    if (!sl.classList.contains('no-chaps') && CHAPS.includes(ch) && !$('.chaps', sl)) {
      const c = document.createElement('div');
      c.className = 'chaps';
      c.setAttribute('aria-hidden', 'true');
      const at = CHAPS.indexOf(ch);
      c.innerHTML = CHAPS.map((n, k) => '<span class="' + (k === at ? 'cur' : k < at ? 'done' : '') + '">' + (k + 1) + ' ' + n + '</span>').join('');
      sl.appendChild(c);
    }
    sl._min = +(sl.dataset.min || 0);
    // sources live in the speaker notes, not on the slide
    sl._src = sl.dataset.src || '';
  }

  function typeOut(el, done) {
    const full = el._full || '';
    if (Deck.reduced || Deck.doc) { el.textContent = full; if (done) done(); return; }
    el.textContent = '';
    el.classList.add('typing');
    const speed = +(el.dataset.type || 22);
    let i = 0;
    const tick = () => {
      i = Math.min(full.length, i + (full.length > 90 ? 3 : full.length > 45 ? 2 : 1));
      el.textContent = full.slice(0, i);
      if (i < full.length) Deck.later(tick, speed);
      else { el.classList.remove('typing'); if (done) Deck.later(done, 120); }
    };
    Deck.later(tick, +(el.dataset.typeDelay || 160));
  }
  function typeSeq(list, instant) {
    if (!list.length) return;
    if (instant) { list.forEach((t) => { t.textContent = t._full; t.classList.remove('typing'); }); return; }
    // blank all first so later lines don't flash before their turn
    list.forEach((t) => { t.textContent = ''; });
    let k = 0;
    const nextOne = () => { if (k < list.length) typeOut(list[k++], nextOne); };
    nextOne();
  }

  function apply(sl, s, dir, instant) {
    sl._els.forEach((el) => {
      const on = s >= el._s && !(el._o && s >= el._o);
      const was = el.classList.contains('on');
      el.classList.toggle('on', on);
      el.classList.toggle('now', s === el._s);
      el.classList.toggle('out', !!(el._o && s >= el._o));
      if (on && !was) {
        const typers = el.matches('[data-type]') ? [el] : $$('[data-type]', el);
        typeSeq(typers, instant);
      }
    });
    // typers that are never inside steps
    sl._focus.forEach(({ pre, map }) => {
      const set = map[s];
      pre.classList.toggle('focusing', !!set);
      $$('.ln', pre).forEach((ln, i) => ln.classList.toggle('f', !!(set && set.has(i + 1))));
    });
  }

  function snap(sl) {
    sl.classList.add('snap');
    // force style flush then release on next frames
    void sl.offsetWidth;
    requestAnimationFrame(() => requestAnimationFrame(() => sl.classList.remove('snap')));
  }

  function renderDemo(sl, s, dir, instant) {
    const name = sl.dataset.demo;
    if (!name) return;
    const d = Deck.demos[name];
    if (!d) return;
    if (!sl._inited) { sl._inited = true; try { d.init && d.init(sl); } catch (e) { console.error(e); } }
    try { d.render && d.render(sl, s, { dir, instant: instant || Deck.doc }); } catch (e) { console.error(e); }
  }

  function leaveDemo(sl) {
    const d = sl.dataset.demo && Deck.demos[sl.dataset.demo];
    Deck.clearTimers();
    if (window.DeckH) window.DeckH.stopAll(sl);
    if (d && d.leave) { try { d.leave(sl); } catch (e) { console.error(e); } }
  }

  function go(i, s = 0, opts = {}) {
    const N = Deck.slides.length;
    i = clamp(i, 0, N - 1);
    const from = Deck.cur;
    const changed = i !== from || !Deck._shown;
    const sl = Deck.slides[i];
    s = s === 'end' ? sl._n : clamp(s, 0, sl._n);
    const dir = opts.dir || (i > from ? 1 : i < from ? -1 : s >= Deck.step ? 1 : -1);
    const instant = !!opts.instant;
    if (changed) {
      if (Deck._shown) leaveDemo(Deck.slides[from]);
      Deck.slides.forEach((x, k) => {
        x.classList.toggle('active', k === i);
        x.classList.toggle('past', k < i);
        x.classList.toggle('future', k > i);
        x.setAttribute('aria-hidden', k === i ? 'false' : 'true');
        if (k !== i) x.inert = true; else x.inert = false;
      });
      Deck._shown = true;
      if (s > 0 || instant) snap(sl);
    } else if (instant) snap(sl);
    Deck.cur = i; Deck.step = s;
    if (changed) sl._typers.forEach((t) => { t.textContent = t._full; t.classList.remove('typing'); });
    apply(sl, s, dir, instant || (changed && s > 0));
    if (changed) typeSeq(sl._typers0, instant || s > 0 || dir < 0);
    renderDemo(sl, s, dir, instant || dir < 0);
    if (!Deck.started && (i > 0 || s > 0)) Deck.started = Date.now();
    updateChrome();
  }

  function next() {
    const sl = Deck.slides[Deck.cur];
    if (Deck.step < sl._n) go(Deck.cur, Deck.step + 1, { dir: 1 });
    else if (Deck.cur < Deck.slides.length - 1) go(Deck.cur + 1, 0, { dir: 1 });
  }
  function prev() {
    if (Deck.step > 0) go(Deck.cur, Deck.step - 1, { dir: -1 });
    else if (Deck.cur > 0) go(Deck.cur - 1, 'end', { dir: -1, instant: true });
  }
  function nextSlide() { if (Deck.cur < Deck.slides.length - 1) go(Deck.cur + 1, 0, { dir: 1 }); }
  function prevSlide() { if (Deck.cur > 0) go(Deck.cur - 1, 0, { dir: -1, instant: true }); }
  Deck.next = next; Deck.prev = prev; Deck.go = go;

  /* ---------------- chrome: HUD, progress, notes, TOC ---------------- */
  let hud, progress, notesPanel, tocOverlay, helpOverlay, blackout, toastEl;
  function icon(name) {
    const p = {
      prev: '<path d="M10 3 5 8l5 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
      next: '<path d="m6 3 5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
      toc: '<path d="M2.5 4h11M2.5 8h11M2.5 12h7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
      notes: '<path d="M3 2.5h10v11H3z M5.5 6h5M5.5 9h5M5.5 12h3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/>',
      theme: '<path d="M8 2.2a5.8 5.8 0 1 0 0 11.6z" fill="currentColor"/><circle cx="8" cy="8" r="5.8" fill="none" stroke="currentColor" stroke-width="1.4"/>',
      full: '<path d="M2.5 6V2.5H6M10 2.5h3.5V6M13.5 10v3.5H10M6 13.5H2.5V10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
      help: '<circle cx="8" cy="8" r="6" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M6.3 6.3a1.8 1.8 0 1 1 2.4 1.7c-.5.2-.7.6-.7 1.1v.4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><circle cx="8" cy="11.6" r=".8" fill="currentColor"/>',
    }[name];
    return '<svg viewBox="0 0 16 16" aria-hidden="true">' + p + '</svg>';
  }
  function buildChrome() {
    hud = document.createElement('div');
    hud.className = 'hud';
    hud.innerHTML =
      '<div class="hbox">' +
      '<button type="button" data-act="prev" aria-label="Previous (←)" title="Previous (←)">' + icon('prev') + '</button>' +
      '<span class="count" aria-live="polite"></span>' +
      '<button type="button" data-act="next" aria-label="Next (→)" title="Next (→)">' + icon('next') + '</button>' +
      '</div><div class="spacer"></div><div class="hbox">' +
      '<button type="button" data-act="toc" title="Slides (O)">' + icon('toc') + '<span>O</span></button>' +
      '<button type="button" data-act="notes" title="Speaker notes (N)">' + icon('notes') + '<span>N</span></button>' +
      '<button type="button" data-act="full" title="Fullscreen (F)">' + icon('full') + '<span>F</span></button>' +
      '<button type="button" data-act="help" title="Keyboard shortcuts (?)">' + icon('help') + '</button>' +
      '</div>';
    document.body.appendChild(hud);
    hud.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-act]');
      if (!b) return;
      const a = b.dataset.act;
      if (a === 'prev') prev();
      else if (a === 'next') next();
      else if (a === 'toc') toggleToc();
      else if (a === 'notes') toggleNotes();
      else if (a === 'full') toggleFull();
      else if (a === 'help') toggleHelp();
      b.blur();
    });

    progress = document.createElement('div');
    progress.className = 'progress';
    Deck.chapters.forEach((c) => {
      const seg = document.createElement('div');
      seg.className = 'seg';
      seg.style.flex = String(c.count);
      seg.title = c.name;
      seg.innerHTML = '<i></i>';
      seg.addEventListener('click', () => go(c.start, 0, { instant: true }));
      progress.appendChild(seg);
      c.el = seg;
    });
    document.body.appendChild(progress);

    notesPanel = document.createElement('div');
    notesPanel.className = 'notes-panel';
    notesPanel.setAttribute('role', 'region');
    notesPanel.setAttribute('aria-label', 'Speaker notes');
    document.body.appendChild(notesPanel);

    tocOverlay = document.createElement('div');
    tocOverlay.className = 'overlay';
    tocOverlay.innerHTML = '<div class="panel" role="dialog" aria-label="All slides"><h3>Jump to a slide</h3><div class="toc"></div></div>';
    const toc = $('.toc', tocOverlay);
    Deck.chapters.forEach((c) => {
      const box = document.createElement('div');
      box.className = 'ch';
      box.innerHTML = '<h4>' + Deck.esc(c.name) + '</h4>';
      for (let k = c.start; k < c.start + c.count; k++) {
        const b = document.createElement('button');
        b.type = 'button';
        b.innerHTML = '<span>' + (k + 1) + '</span>' + Deck.esc(Deck.slides[k]._title || 'Slide ' + (k + 1));
        b.addEventListener('click', () => { closeOverlays(); go(k, 0, { instant: true }); });
        b.dataset.k = k;
        box.appendChild(b);
      }
      toc.appendChild(box);
    });
    tocOverlay.addEventListener('click', (e) => { if (e.target === tocOverlay) closeOverlays(); });
    document.body.appendChild(tocOverlay);

    helpOverlay = document.createElement('div');
    helpOverlay.className = 'overlay';
    helpOverlay.innerHTML = '<div class="panel" role="dialog" aria-label="Keyboard shortcuts" style="max-width:620px"><h3>Presenting</h3><table class="keys">' +
      [['→ &nbsp;Space &nbsp;PgDn', 'Next build / next slide'], ['← &nbsp;PgUp &nbsp;Backspace', 'Previous build'], ['Shift + → / ←', 'Skip whole slide'],
       ['Home / End', 'First / last slide'], ['12 then Enter', 'Jump to slide 12'], ['O', 'Slide list'], ['N', 'Speaker notes + timer'],
       ['F', 'Fullscreen'], ['B or .', 'Black screen'], ['Esc', 'Close panels']]
        .map((r) => '<tr><td><kbd>' + r[0].split(' &nbsp;').join('</kbd> <kbd>') + '</kbd></td><td>' + r[1] + '</td></tr>').join('') +
      '</table><p style="margin-top:14px;color:var(--ink-3);font-size:13px">Clickers that send PageUp / PageDown / B work out of the box. Demo slides also have their own buttons.</p></div>';
    helpOverlay.addEventListener('click', (e) => { if (e.target === helpOverlay) closeOverlays(); });
    document.body.appendChild(helpOverlay);

    blackout = document.createElement('div');
    blackout.className = 'blackout';
    blackout.addEventListener('click', () => blackout.classList.remove('on'));
    document.body.appendChild(blackout);

    toastEl = document.createElement('div');
    toastEl.className = 'toast';
    document.body.appendChild(toastEl);
  }

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('on');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove('on'), 1400);
  }

  function fmtTime(ms) {
    const s = Math.floor(ms / 1000);
    return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }

  function plannedStart(i) {
    let m = 0;
    for (let k = 0; k < i; k++) m += Deck.slides[k]._min || 0;
    return m * 60000;
  }
  function updateNotes() {
    if (!notesPanel || !notesPanel.classList.contains('open')) return;
    const sl = Deck.slides[Deck.cur];
    const n = $('.notes', sl);
    const nxt = Deck.slides[Deck.cur + 1];
    const elapsed = Deck.started ? Date.now() - Deck.started : 0;
    const plan = plannedStart(Deck.cur);
    const diff = elapsed - plan;
    const pace = !Deck.started ? '' : Math.abs(diff) < 30000 ? ' · on time' : diff > 0 ? ' · ' + fmtTime(diff) + ' behind' : ' · ' + fmtTime(-diff) + ' ahead';
    const cls = !Deck.started || Math.abs(diff) < 30000 ? '' : diff > 0 ? 'behind' : 'ahead';
    notesPanel.innerHTML = '<div class="nhead"><span><b>' + (Deck.cur + 1) + ' / ' + Deck.slides.length + '</b> · build ' + Deck.step + '/' + sl._n +
      (sl._min ? ' · ~' + sl._min + ' min' : '') + (nxt ? ' · next: ' + Deck.esc(nxt._title) : '') + '</span>' +
      '<span class="tnum pace ' + cls + '">⏱ ' + fmtTime(elapsed) + ' / plan ' + fmtTime(plan) + pace + '</span></div>' +
      (n ? n.innerHTML : '<p style="color:var(--ink-3)">No notes for this slide.</p>') +
      (sl._src ? '<p class="nsrc">Source: ' + sl._src + '</p>' : '');
  }

  function updateChrome() {
    const sl = Deck.slides[Deck.cur];
    if (hud) {
      $('.count', hud).innerHTML = (Deck.cur + 1) + ' <i>/ ' + Deck.slides.length + '</i>' + (sl._n ? ' <i>· ' + Deck.step + '/' + sl._n + '</i>' : '');
    }
    Deck.chapters.forEach((c) => {
      if (!c.el) return;
      const done = clamp(Deck.cur - c.start + 1, 0, c.count);
      c.el.firstChild.style.width = (done / c.count) * 100 + '%';
    });
    if (tocOverlay) $$('.toc button', tocOverlay).forEach((b) => b.classList.toggle('cur', +b.dataset.k === Deck.cur));
    updateNotes();
    const h = '#' + (Deck.cur + 1) + (Deck.step ? '.' + Deck.step : '');
    if (location.hash !== h) { try { history.replaceState(null, '', h); } catch (e) { /* sandboxed */ } }
    document.title = Deck.baseTitle + (Deck.cur ? ' · ' + (Deck.cur + 1) : '');
  }

  function toggleNotes() {
    notesPanel.classList.toggle('open');
    updateNotes();
    showHud();
  }
  function toggleToc() {
    const open = !tocOverlay.classList.contains('open');
    closeOverlays();
    if (open) { tocOverlay.classList.add('open'); const c = $('.toc button.cur', tocOverlay); if (c) c.focus(); }
  }
  function toggleHelp() {
    const open = !helpOverlay.classList.contains('open');
    closeOverlays();
    if (open) helpOverlay.classList.add('open');
  }
  function closeOverlays() {
    [tocOverlay, helpOverlay].forEach((o) => o && o.classList.remove('open'));
  }
  function toggleFull() {
    const d = document;
    try {
      if (!d.fullscreenElement) {
        const p = d.documentElement.requestFullscreen && d.documentElement.requestFullscreen();
        if (p && p.catch) p.catch(() => toast('Fullscreen is not available here'));
      } else if (d.exitFullscreen) d.exitFullscreen();
    } catch (e) { toast('Fullscreen is not available here'); }
  }

  let hudTimer;
  function showHud() {
    if (!hud) return;
    hud.classList.add('show');
    clearTimeout(hudTimer);
    hudTimer = setTimeout(() => { if (!hud.matches(':hover')) hud.classList.remove('show'); }, 2600);
  }

  /* ---------------- input ---------------- */
  let digits = '', digitTimer;
  function onKey(e) {
    const t = e.target;
    const typing = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
    if (e.key === 'Escape') {
      closeOverlays();
      if (blackout.classList.contains('on')) blackout.classList.remove('on');
      return;
    }
    if (typing) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (Deck.doc) return;
    const k = e.key;
    if (blackout.classList.contains('on') && !['b', 'B', '.'].includes(k)) { blackout.classList.remove('on'); e.preventDefault(); return; }
    if (tocOverlay.classList.contains('open') && !['o', 'O', 'g', 'G'].includes(k)) return;
    let handled = true;
    if (/^[0-9]$/.test(k)) {
      digits += k; clearTimeout(digitTimer);
      digitTimer = setTimeout(() => { digits = ''; }, 1600);
      toast('Go to slide ' + digits + ' ⏎');
    } else if (k === 'Enter' && digits) {
      go(+digits - 1, 0, { instant: true }); digits = '';
    } else if (k === 'ArrowRight' || k === 'PageDown' || k === ' ' || k === 'ArrowDown' || k === 'Enter') {
      if (e.shiftKey && (k === 'ArrowRight' || k === 'PageDown')) nextSlide(); else next();
    } else if (k === 'ArrowLeft' || k === 'PageUp' || k === 'Backspace' || k === 'ArrowUp') {
      if (e.shiftKey && (k === 'ArrowLeft' || k === 'PageUp')) prevSlide(); else prev();
    } else if (k === 'Home') go(0, 0, { instant: true });
    else if (k === 'End') go(Deck.slides.length - 1, 0, { instant: true });
    else if (k === 'o' || k === 'O' || k === 'g' || k === 'G') toggleToc();
    else if (k === 'n' || k === 'N') toggleNotes();
    else if (k === 'f' || k === 'F') toggleFull();
    else if (k === 'b' || k === 'B' || k === '.') blackout.classList.toggle('on');
    else if (k === '?') toggleHelp();
    else handled = false;
    if (handled) e.preventDefault();
  }

  function onTouch() {
    let x0 = null, y0 = null, t0 = 0;
    const stage = $('.stage');
    stage.addEventListener('touchstart', (e) => {
      if (Deck.doc || e.touches.length !== 1) return;
      x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; t0 = Date.now();
    }, { passive: true });
    stage.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4 && Date.now() - t0 < 700) (dx < 0 ? next : prev)();
      x0 = null;
    }, { passive: true });
  }

  /* ---------------- doc mode ---------------- */
  function setDoc(on) {
    Deck.doc = on;
    document.body.classList.toggle('doc', on);
    if (on) {
      Deck.slides.forEach((sl) => {
        sl.inert = false; sl.setAttribute('aria-hidden', 'false');
        apply(sl, sl._n, 1, true);
        renderDemo(sl, sl._n, 1, true);
      });
    } else {
      Deck.slides.forEach((sl) => apply(sl, 0, -1, true));
      Deck._shown = false;
      go(Deck.cur, Deck.step, { instant: true });
    }
  }

  /* ---------------- boot ---------------- */
  Deck.start = function start() {
    Deck.baseTitle = document.title;
    Deck.slides = $$('.stage > .slide');
    Deck.slides.forEach((sl, i) => prepSlide(sl, i));
    highlightAll(document);
    // chapters
    Deck.slides.forEach((sl, i) => {
      const name = sl.dataset.chapter || '';
      const last = Deck.chapters[Deck.chapters.length - 1];
      if (!last || last.name !== name) Deck.chapters.push({ name, start: i, count: 1 });
      else last.count++;
    });
    buildChrome();
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousemove', showHud, { passive: true });
    onTouch();
    setInterval(() => { if (notesPanel.classList.contains('open')) updateNotes(); }, 1000);
    // initial position from hash (#12 or #12.3)
    const m = /^#(\d+)(?:\.(\d+))?$/.exec(location.hash || '');
    const i0 = m ? clamp(+m[1] - 1, 0, Deck.slides.length - 1) : 0;
    const s0 = m && m[2] ? +m[2] : 0;
    if (docMQ.matches) { Deck.cur = i0; setDoc(true); }
    else go(i0, s0, { instant: true });
    docMQ.addEventListener('change', (e) => setDoc(e.matches));
    window.addEventListener('hashchange', () => {
      const mm = /^#(\d+)(?:\.(\d+))?$/.exec(location.hash || '');
      if (mm && (+mm[1] - 1 !== Deck.cur || +(mm[2] || 0) !== Deck.step)) go(+mm[1] - 1, +(mm[2] || 0), { instant: true });
    });
    document.documentElement.classList.add('ready');
  };
})();
