#!/usr/bin/env python3
"""Assemble the deck into one self-contained HTML file.

  python3 build.py                      # writes ../index.html (next to this src/ folder)
  python3 build.py --out DIR            # writes DIR/index.html
  python3 build.py --publish FILE       # also writes a body-only variant for Artifact publishing
"""
import argparse
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent

TITLE = "Skills That Fire, Work &amp; Learn"
DESC = ("An interactive talk on Agent Skills: SKILL.md primer, skill design, description "
        "optimization for activation accuracy, evaluation, observability feedback loops, "
        "and a live SkillOpt training demo.")
FONTS = ("https://fonts.googleapis.com/css2?family=Archivo:ital,wdth,wght@0,62..125,100..900;"
         "1,62..125,100..900&family=JetBrains+Mono:ital,wght@0,400..800;1,400..700&display=swap")

CSS = ["styles.css", "components.css", "demos.css"]
JS = ["js/engine.js", "js/demos-basic.js", "js/demo-router.js", "js/demo-lab.js",
      "js/demo-health.js", "js/demo-skillopt.js", "js/demo-vercel.js"]


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def body_html():
    slides = "\n".join(p.read_text(encoding="utf-8") for p in sorted((ROOT / "slides").glob("*.html")))
    scripts = "\n".join(f"<script>\n{read(j)}\n</script>" for j in JS)
    return ('<div class="viewport"><main class="stage" aria-live="off">\n'
            f"{slides}\n</main></div>\n{scripts}\n<script>Deck.start();</script>\n")


def head_bits():
    css = "\n".join(read(c) for c in CSS)
    return (f"<title>{TITLE}</title>\n"
            f'<meta name="description" content="{DESC}">\n'
            '<link rel="preconnect" href="https://fonts.googleapis.com">\n'
            '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
            f'<link rel="stylesheet" href="{FONTS}">\n'
            f"<style>\n{css}\n</style>\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT.parent), help="directory for index.html")
    ap.add_argument("--publish", help="also write a body-only variant to this file")
    args = ap.parse_args()
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    full = ("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
            '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
            f"{head_bits()}</head>\n<body>\n{body_html()}</body>\n</html>\n")
    (out / "index.html").write_text(full, encoding="utf-8")
    print(f"index.html {len(full) / 1024:.0f} KB → {out}")
    if args.publish:
        pub = pathlib.Path(args.publish)
        pub.parent.mkdir(parents=True, exist_ok=True)
        pub.write_text(head_bits() + body_html(), encoding="utf-8")
        print(f"publish variant → {pub}")


if __name__ == "__main__":
    main()
